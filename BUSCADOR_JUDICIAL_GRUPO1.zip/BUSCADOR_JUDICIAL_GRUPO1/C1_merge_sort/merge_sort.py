"""
PROYECTO: BUSCADOR JUDICIAL
COMPONENTE C1: MERGE SORT

Ordena pares (termino, id_documento) mediante Merge Sort.
La implementacion usa indices y un unico arreglo auxiliar reutilizable:
no crea sublistas mediante slicing en las llamadas recursivas.
"""


def merge_sort(datos):
    """Devuelve una copia ordenada de ``datos`` sin modificar la entrada.

    Tiempo: Theta(n log n) en todos los casos.
    Espacio auxiliar: Theta(n) por el arreglo temporal, mas Theta(log n)
    de pila recursiva.
    """
    resultado = list(datos)
    cantidad = len(resultado)

    if cantidad < 2:
        return resultado

    auxiliar = [None] * cantidad
    _merge_sort_indices(resultado, auxiliar, 0, cantidad - 1)
    return resultado


def _merge_sort_indices(datos, auxiliar, inicio, fin):
    """Ordena el intervalo inclusivo [inicio, fin] usando indices."""
    if inicio >= fin:
        return

    medio = (inicio + fin) // 2
    _merge_sort_indices(datos, auxiliar, inicio, medio)
    _merge_sort_indices(datos, auxiliar, medio + 1, fin)
    _mezclar_en_rango(datos, auxiliar, inicio, medio, fin)


def _mezclar_en_rango(datos, auxiliar, inicio, medio, fin):
    """Mezcla dos mitades ordenadas copiando solo la mitad izquierda.

    La mitad derecha permanece en el arreglo original. Al escribir desde
    ``inicio`` hacia la derecha, nunca se sobrescribe un elemento derecho
    que todavía no se haya comparado.
    """
    for indice in range(inicio, medio + 1):
        auxiliar[indice] = datos[indice]

    izquierda = inicio
    derecha = medio + 1
    destino = inicio

    while izquierda <= medio and derecha <= fin:
        if auxiliar[izquierda] <= datos[derecha]:
            datos[destino] = auxiliar[izquierda]
            izquierda += 1
        else:
            datos[destino] = datos[derecha]
            derecha += 1
        destino += 1

    while izquierda <= medio:
        datos[destino] = auxiliar[izquierda]
        izquierda += 1
        destino += 1


def construir_pares(corpus):
    """Extrae pares (palabra, id) sin repetir una palabra por expediente."""
    import re

    pares = []
    for expediente in corpus:
        id_documento = expediente["id"]
        palabras = re.findall(
            r"\b[a-záéíóúüñ]+\b",
            expediente["texto"].lower(),
        )
        palabras_vistas = set()
        for palabra in palabras:
            if palabra not in palabras_vistas:
                pares.append((palabra, id_documento))
                palabras_vistas.add(palabra)
    return pares


if __name__ == "__main__":
    datos = [
        ("contrato", 8),
        ("accidente", 15),
        ("accidente", 3),
        ("demanda", 12),
        ("contrato", 2),
    ]
    print("DATOS ORIGINALES:")
    print(datos)
    print("\nDATOS ORDENADOS:")
    print(merge_sort(datos))
