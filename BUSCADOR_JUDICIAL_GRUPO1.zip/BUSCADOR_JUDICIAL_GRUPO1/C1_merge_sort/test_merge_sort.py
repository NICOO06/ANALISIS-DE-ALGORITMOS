
from C1_merge_sort.merge_sort import (
    merge_sort,
    construir_pares
)

import json
from pathlib import Path


def test_ordenamiento_correcto():

    datos = [
        ("contrato", 8),
        ("accidente", 15),
        ("accidente", 3),
        ("demanda", 12),
        ("contrato", 2)
    ]

    esperado = [
        ("accidente", 3),
        ("accidente", 15),
        ("contrato", 2),
        ("contrato", 8),
        ("demanda", 12)
    ]

    assert merge_sort(datos) == esperado


def test_lista_vacia():
    assert merge_sort([]) == []


def test_un_solo_elemento():

    datos = [("demanda", 5)]

    assert merge_sort(datos) == datos


def test_datos_repetidos():

    datos = [
        ("contrato", 3),
        ("contrato", 3),
        ("contrato", 1)
    ]

    esperado = [
        ("contrato", 1),
        ("contrato", 3),
        ("contrato", 3)
    ]

    assert merge_sort(datos) == esperado


def test_corpus_judicial():

    ruta_corpus = (
        Path(__file__).resolve().parent.parent
        / "datos"
        / "expedientes.json"
    )

    with ruta_corpus.open("r", encoding="utf-8") as archivo:

        corpus = json.load(archivo)

    pares = construir_pares(corpus)

    resultado = merge_sort(pares)

    assert len(resultado) == len(pares)

    for i in range(1, len(resultado)):
        assert resultado[i - 1] <= resultado[i]

    print("Pares generados:", len(pares))
    print("Primeros 10:", resultado[:10])


def test_merge_sort_no_modifica_entrada():
    datos = [("z", 1), ("a", 2), ("m", 3)]
    copia = datos.copy()
    assert merge_sort(datos) == [("a", 2), ("m", 3), ("z", 1)]
    assert datos == copia


def test_merge_sort_entrada_grande_y_orden_inverso():
    datos = list(range(5000, 0, -1))
    resultado = merge_sort(datos)
    assert resultado == list(range(1, 5001))
    assert datos[0] == 5000
