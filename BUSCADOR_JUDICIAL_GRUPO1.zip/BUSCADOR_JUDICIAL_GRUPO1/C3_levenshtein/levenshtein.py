"""
PROYECTO: BUSCADOR JUDICIAL
COMPONENTE C3: PROGRAMACION DINAMICA
ALGORITMO: DISTANCIA DE LEVENSHTEIN

El calculo normal utiliza dos filas de programacion dinamica.
La matriz completa se conserva unicamente para la visualizacion didactica.
Para sugerencias repetidas se puede reutilizar un indice de prefijos del vocabulario.
"""


def construir_tabla(palabra1, palabra2):
    """Construye la matriz completa; se reserva para visualizar y probar."""
    if not isinstance(palabra1, str) or not isinstance(palabra2, str):
        raise ValueError("Las dos palabras deben ser cadenas de texto.")
    m = len(palabra1)
    n = len(palabra2)
    dp = [[0] * (n + 1) for _ in range(m + 1)]

    for i in range(m + 1):
        dp[i][0] = i
    for j in range(n + 1):
        dp[0][j] = j

    for i in range(1, m + 1):
        for j in range(1, n + 1):
            costo = 0 if palabra1[i - 1] == palabra2[j - 1] else 1
            dp[i][j] = min(
                dp[i][j - 1] + 1,
                dp[i - 1][j] + 1,
                dp[i - 1][j - 1] + costo,
            )
    return dp


def distancia_levenshtein(palabra1, palabra2):
    """Calcula distancia con dos filas: Theta(m*n) tiempo y O(min(m,n)) espacio."""
    if not isinstance(palabra1, str) or not isinstance(palabra2, str):
        raise ValueError("Las dos palabras deben ser cadenas de texto.")
    palabra1 = palabra1.lower()
    palabra2 = palabra2.lower()

    # La segunda cadena determina el ancho de las filas; usar la mas corta.
    if len(palabra1) < len(palabra2):
        palabra1, palabra2 = palabra2, palabra1

    m = len(palabra1)
    n = len(palabra2)
    anterior = list(range(n + 1))

    for i in range(1, m + 1):
        actual = [i] + [0] * n
        caracter = palabra1[i - 1]
        for j in range(1, n + 1):
            costo = 0 if caracter == palabra2[j - 1] else 1
            actual[j] = min(
                actual[j - 1] + 1,
                anterior[j] + 1,
                anterior[j - 1] + costo,
            )
        anterior = actual

    return anterior[n]


def distancia_levenshtein_limitada(palabra1, palabra2, limite):
    """Devuelve la distancia exacta si <= limite; en otro caso limite + 1.

    Solo calcula la banda |i-j| <= limite. Es util para filtrar candidatos
    y reduce el trabajo cuando el umbral es pequeño.
    """
    if (
        isinstance(limite, bool)
        or not isinstance(limite, int)
        or limite < 0
    ):
        raise ValueError("El limite de distancia debe ser un entero no negativo.")
    if not isinstance(palabra1, str) or not isinstance(palabra2, str):
        raise ValueError("Las dos palabras deben ser cadenas de texto.")

    palabra1 = palabra1.lower()
    palabra2 = palabra2.lower()
    if len(palabra1) < len(palabra2):
        palabra1, palabra2 = palabra2, palabra1

    m, n = len(palabra1), len(palabra2)
    infinito = limite + 1
    if m - n > limite:
        return infinito
    if n == 0:
        return m if m <= limite else infinito

    anterior = [j if j <= limite else infinito for j in range(n + 1)]

    for i in range(1, m + 1):
        actual = [infinito] * (n + 1)
        if i <= limite:
            actual[0] = i

        inicio = max(1, i - limite)
        fin = min(n, i + limite)
        minimo_fila = infinito

        for j in range(inicio, fin + 1):
            costo = 0 if palabra1[i - 1] == palabra2[j - 1] else 1
            actual[j] = min(
                actual[j - 1] + 1,
                anterior[j] + 1,
                anterior[j - 1] + costo,
            )
            minimo_fila = min(minimo_fila, actual[j])

        if minimo_fila > limite:
            return infinito
        anterior = actual

    return anterior[n] if anterior[n] <= limite else infinito


class _NodoTrie:
    __slots__ = ("hijos", "termino")

    def __init__(self):
        self.hijos = {}
        self.termino = None


class IndiceVocabulario:
    """Trie reutilizable para buscar sugerencias con distancia acotada.

    Cada prefijo comparte el trabajo de programacion dinamica. Si el minimo
    de una fila supera el umbral, se descarta todo el subarbol: no se calcula
    una distancia completa por separado para cada palabra del vocabulario.
    """

    def __init__(self, vocabulario):
        if vocabulario is None:
            raise ValueError("El vocabulario no puede ser None.")
        self.raiz = _NodoTrie()
        self.cantidad_terminos = 0
        self.cantidad_nodos = 1
        self.ultimo_nodos_visitados = 0

        for termino in {str(t).lower() for t in vocabulario if str(t)}:
            nodo = self.raiz
            for caracter in termino:
                if caracter not in nodo.hijos:
                    nodo.hijos[caracter] = _NodoTrie()
                    self.cantidad_nodos += 1
                nodo = nodo.hijos[caracter]
            if nodo.termino is None:
                nodo.termino = termino
                self.cantidad_terminos += 1

    def buscar(self, consulta, distancia_maxima):
        """Devuelve terminos dentro del umbral usando filas por prefijo."""
        if (
            isinstance(distancia_maxima, bool)
            or not isinstance(distancia_maxima, int)
            or distancia_maxima < 0
        ):
            raise ValueError("La distancia maxima debe ser un entero no negativo.")
        if not isinstance(consulta, str):
            raise ValueError("La consulta debe ser una cadena de texto.")

        consulta = consulta.lower()
        ancho = len(consulta)
        fila_inicial = list(range(ancho + 1))
        resultados = []
        visitados = 0

        # Pila explicita: evita alcanzar el limite de recursividad de Python
        # cuando el vocabulario contiene terminos excepcionalmente largos.
        pendientes = [(self.raiz, fila_inicial)]

        while pendientes:
            nodo, fila_anterior = pendientes.pop()

            for caracter, hijo in nodo.hijos.items():
                fila_actual = [fila_anterior[0] + 1] + [0] * ancho

                for columna in range(1, ancho + 1):
                    costo = 0 if consulta[columna - 1] == caracter else 1
                    fila_actual[columna] = min(
                        fila_actual[columna - 1] + 1,
                        fila_anterior[columna] + 1,
                        fila_anterior[columna - 1] + costo,
                    )

                visitados += 1

                if (
                    hijo.termino is not None
                    and fila_actual[ancho] <= distancia_maxima
                ):
                    resultados.append((hijo.termino, fila_actual[ancho]))

                # Ninguna extension del prefijo puede bajar el minimo actual.
                if min(fila_actual) <= distancia_maxima:
                    pendientes.append((hijo, fila_actual))

        self.ultimo_nodos_visitados = visitados
        return resultados


def sugerir_terminos(
    consulta,
    vocabulario,
    max_sugerencias=5,
    distancia_maxima=None,
    indice=None,
):
    """Sugiere términos por distancia y orden alfabético.

    Si se proporciona un IndiceVocabulario y un umbral, la búsqueda comparte
    filas de programación dinámica por prefijo y poda subárboles cuyo mínimo
    ya supera el umbral. Sin índice, conserva el recorrido exhaustivo.
    """
    if (
        isinstance(max_sugerencias, bool)
        or not isinstance(max_sugerencias, int)
        or max_sugerencias < 1
    ):
        raise ValueError("El numero de sugerencias debe ser un entero positivo.")

    if not isinstance(consulta, str):
        raise ValueError("La consulta debe ser una cadena de texto.")
    consulta = consulta.lower().strip()
    if not consulta:
        raise ValueError("La consulta no puede estar vacia.")

    if distancia_maxima is not None and (
        isinstance(distancia_maxima, bool)
        or not isinstance(distancia_maxima, int)
        or distancia_maxima < 0
    ):
        raise ValueError("La distancia maxima debe ser un entero no negativo.")

    if indice is not None and distancia_maxima is not None:
        resultados = indice.buscar(consulta, distancia_maxima)
    else:
        resultados = []
        for termino in vocabulario:
            termino = str(termino).lower()
            if distancia_maxima is None:
                distancia = distancia_levenshtein(consulta, termino)
            else:
                distancia = distancia_levenshtein_limitada(
                    consulta, termino, distancia_maxima
                )
                if distancia > distancia_maxima:
                    continue
            resultados.append((termino, distancia))

    # Ordenar por (distancia, termino) con Merge Sort del proyecto.
    from C1_merge_sort.merge_sort import merge_sort
    resultados_ordenados = merge_sort(
        (distancia, termino) for termino, distancia in resultados
    )
    return [
        (termino, distancia)
        for distancia, termino in resultados_ordenados[:max_sugerencias]
    ]


def mostrar_tabla(palabra1, palabra2):
    """Visualizacion opcional de la matriz completa para fines didacticos."""
    tabla = construir_tabla(palabra1, palabra2)
    print("\nTABLA DE PROGRAMACION DINAMICA")
    print("Palabra 1:", palabra1)
    print("Palabra 2:", palabra2)
    print()
    for fila in tabla:
        print(fila)
    print("\nDistancia:", tabla[len(palabra1)][len(palabra2)])


if __name__ == "__main__":
    vocabulario = [
        "accidente", "contrato", "demanda", "judicial",
        "sentencia", "documento", "proceso",
    ]
    consulta = "accidnete"
    indice = IndiceVocabulario(vocabulario)
    print("BUSCADOR JUDICIAL")
    print("Consulta ingresada:", consulta)
    sugerencias = sugerir_terminos(
        consulta,
        vocabulario,
        max_sugerencias=5,
        distancia_maxima=2,
        indice=indice,
    )
    print("\nSUGERENCIAS")
    for termino, distancia in sugerencias:
        print(f"{termino} | Distancia: {distancia}")
    # La matriz se muestra solo si se solicita expresamente.
    mostrar_tabla("gato", "gata")
