
import pytest

from C3_levenshtein.levenshtein import (
    construir_tabla,
    distancia_levenshtein,
    sugerir_terminos
)


def test_palabras_iguales():

    assert distancia_levenshtein(
        "casa", "casa"
    ) == 0


def test_sustitucion():

    assert distancia_levenshtein(
        "gato", "gata"
    ) == 1


def test_insercion():

    assert distancia_levenshtein(
        "casa", "casas"
    ) == 1


def test_eliminacion():

    assert distancia_levenshtein(
        "contrato", "contrat"
    ) == 1


def test_palabra_vacia():

    assert distancia_levenshtein(
        "", "hola"
    ) == 4


def test_dos_palabras_vacias():

    assert distancia_levenshtein(
        "", ""
    ) == 0


def test_simetria():

    assert distancia_levenshtein(
        "perro", "gato"
    ) == distancia_levenshtein(
        "gato", "perro"
    )


def test_matriz():

    tabla = construir_tabla(
        "gato", "gata"
    )

    assert tabla[4][4] == 1


def test_sugerencia_judicial():

    vocabulario = [
        "accidente",
        "contrato",
        "demanda"
    ]

    resultado = sugerir_terminos(
        "accidnete",
        vocabulario
    )

    assert resultado[0][0] == "accidente"
    assert resultado[0][1] == 2


def test_sugerencias_ordenadas():

    vocabulario = [
        "demanda",
        "contrato",
        "accidente"
    ]

    resultado = sugerir_terminos(
        "accidnete",
        vocabulario
    )

    assert resultado[0][0] == "accidente"


def test_limite_sugerencias():

    vocabulario = [
        "casa",
        "caso",
        "cama",
        "masa"
    ]

    resultado = sugerir_terminos(
        "casa",
        vocabulario,
        max_sugerencias=2
    )

    assert len(resultado) == 2


def test_distancia_maxima():

    resultado = sugerir_terminos(
        "casa",
        ["casa", "perro"],
        distancia_maxima=1
    )

    assert resultado == [("casa", 0)]


def test_consulta_vacia():

    with pytest.raises(ValueError):

        sugerir_terminos(
            "",
            ["casa"]
        )


def test_limite_invalido():

    with pytest.raises(ValueError):

        sugerir_terminos(
            "casa",
            ["casa"],
            max_sugerencias=0
        )


def test_distancia_dos_filas_equivale_a_matriz():
    from C3_levenshtein.levenshtein import distancia_levenshtein

    pares = [
        ("", "abc"),
        ("gato", "gata"),
        ("accidnete", "accidente"),
        ("judicial", "judicatura"),
        ("abcde", ""),
    ]
    for palabra1, palabra2 in pares:
        tabla = construir_tabla(palabra1, palabra2)
        assert distancia_levenshtein(palabra1, palabra2) == tabla[-1][-1]


def test_distancia_limitada_retorna_exacto_o_limite_mas_uno():
    from C3_levenshtein.levenshtein import distancia_levenshtein_limitada

    assert distancia_levenshtein_limitada("gato", "gata", 1) == 1
    assert distancia_levenshtein_limitada("gato", "perro", 2) == 3
    assert distancia_levenshtein_limitada("casa", "casas", 1) == 1


def test_indice_trie_equivale_a_busqueda_exhaustiva():
    from C3_levenshtein.levenshtein import IndiceVocabulario

    vocabulario = [
        "accidente", "contrato", "demanda", "judicial",
        "sentencia", "documento", "proceso", "accidente",
    ]
    indice = IndiceVocabulario(vocabulario)

    for consulta in ["accidnete", "contrto", "demadna", "judical"]:
        for radio in [1, 2, 3]:
            esperado = [
                (termino, distancia_levenshtein(consulta, termino))
                for termino in sorted(set(vocabulario))
                if distancia_levenshtein(consulta, termino) <= radio
            ]
            esperado.sort(key=lambda par: (par[1], par[0]))
            obtenido = indice.buscar(consulta, radio)
            obtenido.sort(key=lambda par: (par[1], par[0]))
            assert obtenido == esperado


def test_sugerencias_usan_indice_trie_reutilizable():
    from C3_levenshtein.levenshtein import IndiceVocabulario

    vocabulario = ["accidente", "contrato", "demanda", "judicial"]
    indice = IndiceVocabulario(vocabulario)
    resultado = sugerir_terminos(
        "accidnete",
        vocabulario,
        max_sugerencias=3,
        distancia_maxima=2,
        indice=indice,
    )
    assert resultado[0] == ("accidente", 2)



def test_trie_no_depende_de_recursion_python():
    from C3_levenshtein.levenshtein import IndiceVocabulario

    termino = "a" * 1200
    indice = IndiceVocabulario([termino])
    assert indice.buscar(termino, 0) == [(termino, 0)]


def test_limites_de_sugerencias_deben_ser_enteros():
    with pytest.raises(ValueError):
        sugerir_terminos("casa", ["casa"], max_sugerencias=1.5)


def test_limite_de_distancia_debe_ser_entero():
    from C3_levenshtein.levenshtein import distancia_levenshtein_limitada
    with pytest.raises(ValueError):
        distancia_levenshtein_limitada("casa", "casa", 1.5)
