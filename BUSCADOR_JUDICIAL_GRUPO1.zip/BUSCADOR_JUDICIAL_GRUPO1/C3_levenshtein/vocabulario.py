
import json
import re
from pathlib import Path


def cargar_vocabulario(ruta_corpus=None):
    """
    Extrae las palabras únicas de los expedientes
    judiciales almacenados en expedientes.json.
    """

    # Ubicación del proyecto
    ruta = (
        Path(ruta_corpus).resolve()
        if ruta_corpus is not None
        else (
            Path(__file__).resolve().parent.parent
            / "datos"
            / "expedientes.json"
        )
    )

    # Leer los expedientes
    with open(ruta, "r", encoding="utf-8") as archivo:
        expedientes = json.load(archivo)

    if not isinstance(expedientes, list):
        raise ValueError(
            "El archivo debe contener una lista de expedientes."
        )

    palabras = set()

    # Recorrer cada expediente
    for expediente in expedientes:

        texto = expediente.get("texto", "")

        if not isinstance(texto, str):
            continue

        # Extraer palabras de mínimo 3 caracteres
        encontradas = re.findall(
            r"[a-záéíóúñü]{3,}",
            texto.lower()
        )

        for palabra in encontradas:
            palabras.add(palabra)

    from C1_merge_sort.merge_sort import merge_sort
    return merge_sort(palabras)


if __name__ == "__main__":

    vocabulario = cargar_vocabulario()

    print("=" * 45)
    print("VOCABULARIO JUDICIAL AUTOMÁTICO")
    print("=" * 45)

    print("Palabras únicas:", len(vocabulario))

    print("\nPrimeros términos:")

    for palabra in vocabulario[:20]:
        print("-", palabra)
