# Experimentos del Buscador Judicial

Ejecutar desde la raíz del repositorio con el entorno virtual activado:

```bash
python experimentos_optimizacion.py
python -m C4_mochila_fraccionaria.experimentos_mochila
python -m C5_arbol_b_mas.experimentos_b_mas
python -m C6_atencion.experimentos_atencion
```

- C1–C3: cinco tamaños por componente; cinco repeticiones; CSV consolidado y gráficas.
- C4: cinco tamaños geométricos de pasajes; cinco repeticiones; mediana, razón `T(P)/(P log₂P)` y gráfica log-log.
- C5: cinco tamaños de registros; cinco repeticiones; memoria limitada a cuatro bloques LRU; CSV con cotas predichas y E/S físicas contadas por fase.
- C6: cinco tamaños de matriz; cinco repeticiones; mediana, dispersión, memoria auxiliar estimada y equivalencia numérica.

Los datos se generan antes de cronometrar. Las cifras de tiempo son dependientes del equipo, versión de Python y bibliotecas.
