"""Ejecuta los experimentos reproducibles de C1 a C6 desde la raíz."""
import subprocess
import sys

COMANDOS = [
    [sys.executable, "experimentos_optimizacion.py"],
    [sys.executable, "-m", "C4_mochila_fraccionaria.experimentos_mochila"],
    [sys.executable, "-m", "C5_arbol_b_mas.experimentos_b_mas"],
    [sys.executable, "-m", "C6_atencion.experimentos_atencion"],
]

for comando in COMANDOS:
    print("\n$", " ".join(comando), flush=True)
    subprocess.run(comando, check=True)

print("\nTodos los experimentos finalizaron correctamente.")
