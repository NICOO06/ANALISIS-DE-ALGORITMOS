# BUSCADOR JUDICIAL – GRUPO 1
## Segunda entrega: respuesta a la retroalimentación docente

**Asignatura:** Análisis de Algoritmos  
**Docente:** Juan David Rodríguez Martínez  
**Integrantes:** Santiago Mejía, Bryan Rodríguez y Nicolás Vargas  
**Fecha:** 17 de noviembre de 2026

---

## 1. Objetivo de la corrección

Esta versión atiende las observaciones recibidas sobre los componentes C1, C2 y C3. Se conserva la integración original del buscador y se modifica únicamente lo necesario para mejorar el uso de memoria, precisar el análisis de complejidad y evitar recorrer individualmente todo el vocabulario en cada consulta de sugerencias.

## 2. C1 – Merge Sort con índices y arreglo auxiliar reutilizable

### Problema identificado

La primera implementación creaba dos sublistas con slicing en cada llamada recursiva. Aunque la recurrencia temporal seguía siendo `T(n) = 2T(n/2) + Θ(n)`, cada partición generaba nuevas listas y copias de referencias que se repetían a través de los niveles recursivos.

### Corrección

La función `merge_sort` ahora:

1. Crea una sola copia de la entrada para preservar el comportamiento anterior: devuelve una lista ordenada sin modificar la original.
2. Reserva un único arreglo auxiliar del tamaño de la entrada.
3. Llama a una función recursiva que recibe los índices `inicio` y `fin`.
4. Mezcla los intervalos sin crear sublistas. Para cada mezcla copia al auxiliar únicamente la mitad izquierda y utiliza dos índices para comparar los elementos.

### Complejidad

- Mejor, promedio y peor caso: `Θ(n log n)`.
- Arreglo auxiliar: `Θ(n)`.
- Pila recursiva: `Θ(log n)`.
- No se crean sublistas por llamada recursiva.

### Validación experimental

El script `experimentos_optimizacion.py` reproduce la versión inicial con slicing y cuenta cuántas llamadas a slicing y cuántas referencias se copian. Para `n = 16.000`, la versión de referencia realiza 31.998 operaciones de slicing que copian en conjunto 223.616 referencias; la nueva versión reserva un único auxiliar de 16.000 posiciones.

En esta ejecución, la versión por índices no fue más rápida en tiempo de pared para los tamaños probados. Esto se registra de forma transparente: las operaciones de slicing de listas están implementadas en C dentro de Python, mientras que la mezcla indexada ejecuta bucles en Python. La corrección se justifica por el control de asignaciones y por la estructura espacial explícita solicitada, no por afirmar una aceleración temporal que las mediciones no muestran.

## 3. C2 – Arreglo dinámico y límite de capacidad

### Corrección conceptual

Se distinguen dos magnitudes:

- `tamano = n`: cantidad de elementos almacenados.
- `capacidad = C`: cantidad de posiciones reservadas.

Siempre se cumple `n ≤ C`. Con una capacidad inicial fija y cuando `n` supera dicha capacidad inicial, la política de duplicación mantiene `C < 2n`. Por eso el espacio reservado es `Θ(n)`, pero no es exactamente igual al número de elementos: puede haber posiciones vacías cercanas a la mitad de la capacidad después de una redimensión.

### Cambios en el código

`obtener_estadisticas()` ahora incluye:

- `espacio_sin_utilizar = capacidad - elementos`.
- `factor_ocupacion = elementos / capacidad`.
- `maximo_tamano_historico`, para explicar la capacidad retenida si luego se eliminan elementos.

Se mantiene sin cambios el método contable de tres créditos por inserción y su verificación de saldo no negativo.

## 4. C3 – Levenshtein con dos filas e índice de prefijos

### Cálculo de distancia

La función `distancia_levenshtein` ya no construye la matriz completa. Mantiene únicamente la fila anterior y la fila actual, y coloca la cadena más corta en las columnas.

- Tiempo por comparación: `Θ(mn)`.
- Espacio auxiliar: `Θ(min(m,n))`.

La función `construir_tabla` se conserva para pruebas y visualización didáctica. La visualización no se ejecuta en cada consulta normal del buscador.

### Búsqueda de sugerencias

Se agregó `IndiceVocabulario`, una estructura trie construida una sola vez al inicializar `BuscadorJudicial`. Durante una consulta, el algoritmo propaga una fila de programación dinámica por cada prefijo compartido. Si el valor mínimo de una fila supera la distancia máxima permitida, se descarta el subárbol completo porque ninguna extensión de ese prefijo puede volver a alcanzar el umbral.

Si `P` es el número de nodos del trie visitados y `m` la longitud de la consulta, el trabajo de una búsqueda acotada es `O(Pm)`. En el peor caso se pueden recorrer todos los prefijos del vocabulario; por tanto, el trie no elimina el peor caso lineal respecto al tamaño del índice, pero evita calcular una distancia completa e independiente para cada término cuando la poda es efectiva. La construcción inicial cuesta `O(T)`, donde `T` es la suma de las longitudes de los términos, y se reutiliza entre consultas.

### Validación

Se conservaron las pruebas originales de matriz y sugerencias. Se agregaron pruebas para la versión de dos filas, distancia acotada y equivalencia del trie frente al recorrido exhaustivo. Además, se realizó una validación adicional con 1.000 combinaciones aleatorias de vocabularios, consultas y radios de distancia; los resultados del trie coincidieron con el recorrido exhaustivo en todos los casos.

## 5. Resultados de pruebas automatizadas

La versión del paquete que se entregó inicialmente tenía 99 pruebas aprobadas. Tras la auditoría integral y las correcciones adicionales, la suite completa reporta:

**120 passed**.

También se comprobó la compilación de los archivos Python y el inicio del menú principal. El buscador carga los 100 expedientes del corpus.

## 6. Resultados experimentales observados

Los resultados se generaron ejecutando `python experimentos_optimizacion.py`. La generación de datos ocurre antes de iniciar los cronómetros. Los tiempos son medianas de varias repeticiones y dependen del equipo.

### C1 – Asignaciones por slicing

| n | Llamadas a slicing | Referencias copiadas por slicing | Auxiliar único |
|---:|---:|---:|---:|
| 1.000 | 1.998 | 9.976 | 1.000 |
| 2.000 | 3.998 | 21.952 | 2.000 |
| 4.000 | 7.998 | 47.904 | 4.000 |
| 8.000 | 15.998 | 103.808 | 8.000 |
| 16.000 | 31.998 | 223.616 | 16.000 |

La columna de referencias copiadas representa el volumen acumulado de elementos trasladados por slicing, no el máximo de memoria residente simultánea.

### C3 – Memoria de programación dinámica

| Longitud de cada cadena | Pico matriz completa | Pico dos filas | Reducción observada |
|---:|---:|---:|---:|
| 32 | 9.160 B | 1.042 B | 88,6 % |
| 64 | 34.536 B | 1.874 B | 94,6 % |
| 128 | 137.296 B | 3.538 B | 97,4 % |
| 256 | 540.720 B | 6.866 B | 98,7 % |
| 512 | 4.239.480 B | 25.962 B | 99,4 % |

### C3 – Poda del trie

En el vocabulario real del corpus, con 36 términos y radio 2, el trie tiene 253 nodos y visitó 83 para la consulta experimental `accidnete`. En ese vocabulario pequeño, la medición del trie fue ligeramente más lenta que el recorrido exhaustivo acotado (0,000103 s frente a 0,000086 s). En vocabularios sintéticos de 100, 500 y 1.000 términos, la búsqueda con trie fue más rápida en esta ejecución, con radio 2. En 1.000 términos, el trie visitó 1.796 de sus 5.560 nodos. El CSV conserva tiempos y conteos de cada ejecución.

### C5 – Árbol B+ y disco simulado

Se agregó el script que estaba vacío, `C5_arbol_b_mas/experimentos_b_mas.py`. Mide medianas de inserción, búsqueda puntual y búsqueda por rango para 100, 500, 1.000 y 2.000 registros, con tres repeticiones. Los resultados se guardan en `C5_arbol_b_mas/resultados_b_mas.csv`. La implementación también valida fechas de calendario reales en formato ISO y cuenta solo parejas fecha-identificador únicas.

### C6 – Atención por bloques

La ejecución conserva equivalencia numérica en todos los tamaños probados. Para 2.048 elementos, la memoria auxiliar estimada fue de 64,53 MB en atención exacta y 0,60 MB en atención por bloques. En ese tamaño, la atención por bloques tardó más en este entorno (medianas de 0,0956 s frente a 0,0518 s). Por ello se presenta como una alternativa de menor memoria, no como una aceleración garantizada.

## 7. Entorno y reproducibilidad

La ejecución de validación de este informe se realizó en Python 3.13.5 sobre Linux x86_64. El equipo del estudiante puede reportar tiempos diferentes. Para reproducir las pruebas y experimentos desde la carpeta raíz del proyecto:

```powershell
python -m pytest -v
python experimentos_optimizacion.py
```

Los resultados detallados se guardan en `resultados_optimizacion.csv`.

## 8. Conclusión

C1 ahora implementa Merge Sort por índices con un auxiliar reutilizable; C2 conserva el método contable y explicita el límite entre tamaño y capacidad; C3 reduce el espacio del cálculo de Levenshtein a dos filas y añade búsqueda por prefijos con poda para evitar evaluar exhaustivamente cada término en consultas con umbral. Las 120 pruebas aprobadas y las validaciones adicionales respaldan que las modificaciones mantienen la integración funcional del proyecto.


## Nota de auditoria adicional del paquete

La revision integral del paquete incluyo validacion de fechas reales para C5, conteo de inserciones unicas en el arbol B+, validacion estricta de parametros, seleccion parcial de C4 a nivel de palabras (el numero de palabras coincide con el presupuesto de tokens asignado), uso del corpus indicado al construir el vocabulario y correccion de las estimaciones de memoria de C6. El archivo de experimentos de C5 tambien fue implementado; antes estaba vacio.

La medicion no muestra que cada optimizacion sea mas rapida en todos los escenarios. C1 elimina slicing y reduce asignaciones auxiliares, aunque el bucle por indices de Python puede tardar algo mas. C3 muestra ventajas del trie en vocabularios sinteticos mayores, mientras que para el vocabulario pequeno del corpus real el costo de construir/recorrer el trie puede ser similar o mayor. C6 por bloques reduce memoria estimada pero puede tardar mas que la atencion exacta en estos tamanos.
