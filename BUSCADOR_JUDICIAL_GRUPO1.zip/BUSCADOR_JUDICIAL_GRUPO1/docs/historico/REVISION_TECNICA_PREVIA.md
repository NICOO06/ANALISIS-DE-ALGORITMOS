# REVISION TECNICA DEL CODIGO – BUSCADOR JUDICIAL GRUPO 1

## Alcance de la revision

Se reviso el paquete `BUSCADOR_JUDICIAL_GRUPO1_SEGUNDA_ENTREGA.zip` que se habia entregado anteriormente. La revision cubrio los 29 archivos Python del proyecto, las pruebas, el menu integrado, los scripts de experimentos y los archivos de datos. Los cinco `__init__.py` vacios son archivos de paquete y se dejan asi intencionalmente.

## Resultado final de validacion

- Suite completa: **120 pruebas aprobadas**.
- Compilacion de todos los modulos con `compileall`: correcta.
- Menu principal: arranca y cierra correctamente.
- Busqueda con error de escritura: propone `accidente` para `accidnete`.
- Recuperacion de pasajes: respeta el presupuesto de tokens y el texto parcial corresponde al numero de palabras asignadas.
- Experimentos C1-C3, C5 y C6: ejecutados y guardan sus resultados.
- Pruebas adicionales aleatorias: Merge Sort comparado con `sorted` en 1.000 entradas; arreglo dinamico comparado con una lista de referencia durante 20.000 operaciones; trie y distancia acotada comparados con busqueda exhaustiva en 1.000 combinaciones; arbol B+ contrastado en cinco ordenes y diez semillas.

## Correcciones realizadas

### C1 – Merge Sort
- Las llamadas recursivas usan indices `inicio`, `medio` y `fin`.
- Se reserva un unico arreglo auxiliar reutilizable.
- No se crean sublistas con slicing en las llamadas recursivas.
- Se conserva el contrato de devolver una lista nueva sin modificar la entrada.
- La prueba del corpus localiza `datos/expedientes.json` desde la ubicacion del archivo de prueba, no desde el directorio actual.

### C2 – Arreglo dinamico
- La capacidad inicial ahora debe ser un entero positivo.
- Las estadisticas distinguen tamaño logico, capacidad, espacio libre, ocupacion y maximo tamaño historico.
- Se conserva el metodo contable de tres creditos.
- Se aclara que el arreglo no se contrae al eliminar: la cota `capacidad < 2n` corresponde a inserciones sin eliminaciones, no necesariamente al tamaño actual despues de borrar.

### C3 – Levenshtein
- El calculo normal utiliza dos filas y espacio `O(min(m,n))`.
- La matriz completa queda para visualizacion y pruebas.
- La distancia acotada valida su parametro y calcula una banda.
- El trie comparte prefijos y poda subarboles.
- El recorrido del trie usa una pila explicita para no depender de la profundidad recursiva de Python.
- El vocabulario se construye desde el corpus configurado en `BuscadorJudicial`, tambien cuando se usa una ruta personalizada.

### C4 – Mochila fraccionaria
- Los tokens deben ser enteros positivos y coincidir con la cantidad de palabras separadas por espacios del pasaje.
- La seleccion parcial ahora corta por palabras, no por una proporcion arbitraria de caracteres.
- Los tokens reportados corresponden al texto que realmente se entrega.

### C5 – Arbol B+ y disco simulado
- Las fechas se validan como fechas reales `AAAA-MM-DD`.
- El orden del arbol, el tamaño de bloque y los indices de bloque se validan.
- El contador de elementos aumenta solo cuando se inserta una pareja fecha-identificador nueva.
- Se completo `experimentos_b_mas.py`, que estaba vacio, y se genero el CSV comparativo.

### C6 – Atencion
- Los tamaños de bloque deben ser enteros positivos.
- Se validan valores no finitos y puntuaciones que exceden el rango numerico.
- Se corrigieron las estimaciones de memoria para incluir salida y acumuladores.
- La documentacion distingue memoria reducida de velocidad: la atencion por bloques puede consumir menos memoria y tardar mas.

### Integracion
- La puntuacion de busqueda cuenta palabras completas, no coincidencias parciales de subcadenas.
- Las fechas ingresadas por menu se validan como fechas de calendario.
- El buscador respeta la ruta de corpus que recibe al inicializarse.

## Interpretacion de los experimentos

- C1: la version por indices atiende el diseño espacial solicitado y elimina slicing recursivo. En las mediciones de este entorno no fue mas rapida; los bucles indexados en Python tienen una sobrecarga que no existe en las operaciones de slicing implementadas en C.
- C3: dos filas reducen fuertemente el pico de memoria. El trie no garantiza ser mas rapido en vocabularios pequeños; su utilidad aumenta cuando hay mas terminos y la poda evita recorrer muchos prefijos.
- C6: la atencion por bloques conserva equivalencia numerica y reduce la memoria estimada, pero en los tamaños medidos tardo mas que la atencion exacta.

Los tiempos y estimaciones son propios del entorno donde se ejecutaron y deben volver a medirse en el computador de presentacion.


## Ajuste posterior de la salida de búsqueda

- La puntuación ahora pondera coincidencias en el título (peso 5) y el tipo de expediente (peso 3), además de las coincidencias en el texto (peso 1). Esto ayuda a priorizar expedientes cuyo asunto coincide con la consulta.
- La consola muestra como máximo 10 resultados, conserva el total encontrado y resume cuántos resultados adicionales fueron omitidos.
- La vista previa del texto se redujo a 180 caracteres para que la salida sea legible.
- Se añadieron pruebas para verificar el límite de salida y la priorización por metadatos.
- Validación posterior: 122 pruebas aprobadas y compilación de todos los módulos correcta.
