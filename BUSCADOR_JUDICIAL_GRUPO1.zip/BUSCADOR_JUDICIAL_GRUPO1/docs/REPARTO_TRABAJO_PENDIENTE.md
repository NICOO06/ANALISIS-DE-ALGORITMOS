# Reparto del trabajo — validar antes de entregar

La distribución real no se puede inferir de forma fiable a partir de los archivos. Los integrantes deben completar esta tabla.

| Integrante | Componentes / implementación | Experimentos / pruebas | Integración / documentación |
|---|---|---|---|
| Nicolás Vargas | Por confirmar | Por confirmar | Por confirmar |
| Santiago Mejía | Por confirmar | Por confirmar | Por confirmar |
| Bryan Rodríguez | Por confirmar | Por confirmar | Por confirmar |

**No publicar una atribución hasta que los tres integrantes la revisen y confirmen.**
