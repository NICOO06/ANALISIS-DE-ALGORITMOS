
"""
PROYECTO: BUSCADOR JUDICIAL
COMPONENTE C2: ARREGLO DINAMICO

Implementacion propia de un arreglo dinamico
con duplicacion de capacidad.

Incluye:
- Insercion
- Redimensionamiento
- Acceso por indice
- Modificacion
- Eliminacion
- Conteo de operaciones
- Metodo contable para costo amortizado
"""


class ArregloDinamico:

    def __init__(self, capacidad_inicial=4):

        if (
            isinstance(capacidad_inicial, bool)
            or not isinstance(capacidad_inicial, int)
            or capacidad_inicial < 1
        ):
            raise ValueError(
                "La capacidad inicial debe ser un entero mayor que cero."
            )

        self.capacidad = capacidad_inicial
        self.capacidad_inicial = capacidad_inicial
        self.tamano = 0
        self.maximo_tamano_historico = 0

        # Espacio reservado inicialmente.
        self.datos = [None] * self.capacidad

        # Contadores de operaciones.
        self.copias = 0
        self.inserciones = 0
        self.redimensionamientos = 0
        self.desplazamientos = 0

        # Sistema contable:
        # Cada insercion cobra 3 unidades.
        self.creditos = 0
        self.costo_amortizado_acumulado = 0

    # ---------------------------------
    # REDIMENSIONAMIENTO
    # ---------------------------------

    def _redimensionar(self):

        nueva_capacidad = self.capacidad * 2

        nuevo_arreglo = [None] * nueva_capacidad

        # Copiar manualmente los elementos.
        for i in range(self.tamano):

            nuevo_arreglo[i] = self.datos[i]

            self.copias += 1

        self.datos = nuevo_arreglo
        self.capacidad = nueva_capacidad

        self.redimensionamientos += 1

        # Pagar las copias con creditos acumulados.
        self.creditos -= self.tamano

        if self.creditos < 0:
            raise RuntimeError(
                "Error: creditos insuficientes para las copias."
            )

    # ---------------------------------
    # INSERTAR ELEMENTOS
    # ---------------------------------

    def insertar(self, elemento):

        if self.tamano == self.capacidad:

            self._redimensionar()

        self.datos[self.tamano] = elemento

        self.tamano += 1
        self.maximo_tamano_historico = max(
            self.maximo_tamano_historico,
            self.tamano,
        )

        self.inserciones += 1

        # Costo contable por insercion:
        # 1 unidad para insertar.
        # 2 unidades para ahorrar creditos.

        self.creditos += 2

        self.costo_amortizado_acumulado += 3

    # ---------------------------------
    # CONSULTAR ELEMENTO
    # ---------------------------------

    def obtener(self, indice):

        if indice < 0 or indice >= self.tamano:

            raise IndexError(
                "Indice fuera de los limites del arreglo."
            )

        return self.datos[indice]

    # ---------------------------------
    # MODIFICAR ELEMENTO
    # ---------------------------------

    def modificar(self, indice, nuevo_valor):

        if indice < 0 or indice >= self.tamano:

            raise IndexError(
                "Indice fuera de los limites del arreglo."
            )

        self.datos[indice] = nuevo_valor

    # ---------------------------------
    # ELIMINAR ELEMENTO
    # ---------------------------------

    def eliminar(self, indice):

        if indice < 0 or indice >= self.tamano:

            raise IndexError(
                "Indice fuera de los limites del arreglo."
            )

        eliminado = self.datos[indice]

        # Desplazar los elementos hacia la izquierda.
        for i in range(indice, self.tamano - 1):

            self.datos[i] = self.datos[i + 1]

            self.desplazamientos += 1

        self.tamano -= 1

        self.datos[self.tamano] = None

        return eliminado

    # ---------------------------------
    # CONSULTAR TAMANO
    # ---------------------------------

    def __len__(self):

        return self.tamano

    # ---------------------------------
    # CONVERTIR A LISTA PARA CONSULTA
    # ---------------------------------

    def a_lista(self):

        resultado = []

        for i in range(self.tamano):

            resultado.append(self.datos[i])

        return resultado

    # ---------------------------------
    # MOSTRAR ESTADISTICAS
    # ---------------------------------

    def obtener_estadisticas(self):

        costo_real_inserciones = (
            self.inserciones + self.copias
        )

        return {
            "elementos": self.tamano,
            "maximo_tamano_historico": self.maximo_tamano_historico,
            "capacidad": self.capacidad,
            # Para capacidad inicial fija y n suficientemente grande,
            # la duplicacion mantiene capacidad < 2 * elementos.
            "espacio_sin_utilizar": self.capacidad - self.tamano,
            # Sin contraccion, la cota de capacidad se refiere al maximo
            # historico alcanzado, no necesariamente al tamano actual
            # despues de eliminar elementos.
            "capacidad_menor_que_dos_veces_maximo_historico": (
                self.capacidad < 2 * self.maximo_tamano_historico
                if self.maximo_tamano_historico >= self.capacidad_inicial
                else None
            ),
            "factor_ocupacion": (
                self.tamano / self.capacidad if self.capacidad else 0.0
            ),
            "inserciones": self.inserciones,
            "copias": self.copias,
            "redimensionamientos": self.redimensionamientos,
            "creditos_disponibles": self.creditos,
            "costo_real_inserciones": costo_real_inserciones,
            "costo_amortizado_acumulado":
                self.costo_amortizado_acumulado,
            "desplazamientos": self.desplazamientos
        }

    # ---------------------------------
    # REPRESENTACION DEL ARREGLO
    # ---------------------------------

    def __repr__(self):

        return repr(self.a_lista())


# -----------------------------------------
# PRUEBA MANUAL
# -----------------------------------------

if __name__ == "__main__":

    arreglo = ArregloDinamico(
        capacidad_inicial=2
    )

    print("ARREGLO DINAMICO")
    print("---------------------------")

    for numero in [10, 20, 30, 40, 50, 60]:

        arreglo.insertar(numero)

        print(
            "Insertado:", numero,
            "| Datos:", arreglo,
            "| Capacidad:", arreglo.capacidad
        )

    print("\nESTADISTICAS")

    for clave, valor in arreglo.obtener_estadisticas().items():

        print(f"{clave}: {valor}")
