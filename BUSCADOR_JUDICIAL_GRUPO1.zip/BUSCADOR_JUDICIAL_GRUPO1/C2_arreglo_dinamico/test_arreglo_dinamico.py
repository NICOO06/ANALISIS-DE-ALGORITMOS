
import pytest

from C2_arreglo_dinamico.arreglo_dinamico import (
    ArregloDinamico
)


def test_insercion_basica():

    arreglo = ArregloDinamico(2)

    arreglo.insertar(10)
    arreglo.insertar(20)

    assert arreglo.a_lista() == [10, 20]


def test_duplicacion_capacidad():

    arreglo = ArregloDinamico(2)

    arreglo.insertar(10)
    arreglo.insertar(20)
    arreglo.insertar(30)

    assert arreglo.capacidad == 4

    assert arreglo.a_lista() == [10, 20, 30]


def test_multiples_redimensionamientos():

    arreglo = ArregloDinamico(2)

    for numero in range(10):

        arreglo.insertar(numero)

    assert arreglo.capacidad == 16

    assert len(arreglo) == 10


def test_acceso_por_indice():

    arreglo = ArregloDinamico(3)

    arreglo.insertar(100)
    arreglo.insertar(200)

    assert arreglo.obtener(0) == 100
    assert arreglo.obtener(1) == 200


def test_modificacion():

    arreglo = ArregloDinamico(2)

    arreglo.insertar(10)
    arreglo.insertar(20)

    arreglo.modificar(1, 50)

    assert arreglo.obtener(1) == 50


def test_eliminacion():

    arreglo = ArregloDinamico(4)

    for numero in [10, 20, 30]:

        arreglo.insertar(numero)

    eliminado = arreglo.eliminar(1)

    assert eliminado == 20

    assert arreglo.a_lista() == [10, 30]


def test_indice_invalido():

    arreglo = ArregloDinamico(2)

    with pytest.raises(IndexError):

        arreglo.obtener(5)


def test_capacidad_invalida():

    with pytest.raises(ValueError):

        ArregloDinamico(0)


def test_creditos_no_negativos():

    arreglo = ArregloDinamico(2)

    for numero in range(100):

        arreglo.insertar(numero)

        assert arreglo.creditos >= 0


def test_costo_amortizado():

    arreglo = ArregloDinamico(2)

    for numero in range(100):

        arreglo.insertar(numero)

    estadisticas = arreglo.obtener_estadisticas()

    assert estadisticas["costo_amortizado_acumulado"] == 300

    assert estadisticas["costo_real_inserciones"] <= 300

    assert arreglo.creditos == (
        300 - estadisticas["costo_real_inserciones"]
    )


def test_estadisticas_memoria_reservada():
    arreglo = ArregloDinamico(4)
    for valor in [10, 20, 30, 40, 50]:
        arreglo.insertar(valor)

    estadisticas = arreglo.obtener_estadisticas()
    assert estadisticas["elementos"] == 5
    assert estadisticas["capacidad"] == 8
    assert estadisticas["espacio_sin_utilizar"] == 3
    assert estadisticas["factor_ocupacion"] == 5 / 8


def test_capacidad_lineal_tras_duplicaciones():
    arreglo = ArregloDinamico(2)
    for valor in range(1000):
        arreglo.insertar(valor)

    assert arreglo.capacidad >= len(arreglo)
    assert arreglo.capacidad < 2 * len(arreglo)



def test_capacidad_inicial_debe_ser_entero():
    with pytest.raises(ValueError):
        ArregloDinamico(2.5)
    with pytest.raises(ValueError):
        ArregloDinamico(True)


def test_cota_de_capacidad_se_refiere_al_maximo_historico():
    arreglo = ArregloDinamico(2)
    for valor in range(20):
        arreglo.insertar(valor)
    for _ in range(18):
        arreglo.eliminar(0)

    estadisticas = arreglo.obtener_estadisticas()
    assert estadisticas["elementos"] == 2
    assert estadisticas["maximo_tamano_historico"] == 20
    assert estadisticas["capacidad"] == 32
    assert estadisticas["capacidad_menor_que_dos_veces_maximo_historico"] is True
