
"""
PROYECTO: BUSCADOR JUDICIAL
COMPONENTE C2: INDICE INVERTIDO

Construye listas de posteo utilizando
nuestra implementacion de ArregloDinamico.
"""

from C1_merge_sort.merge_sort import (
    construir_pares,
    merge_sort
)

from C2_arreglo_dinamico.arreglo_dinamico import (
    ArregloDinamico
)


def construir_indice_invertido(
    corpus,
    capacidad_inicial=4
):

    # Obtener pares (termino, documento).
    pares = construir_pares(corpus)

    # Ordenar mediante nuestro Merge Sort.
    pares_ordenados = merge_sort(pares)

    indice = {}

    # Agrupar documentos por termino.
    for termino, id_documento in pares_ordenados:

        if termino not in indice:

            indice[termino] = ArregloDinamico(
                capacidad_inicial
            )

        indice[termino].insertar(id_documento)

    return indice


def buscar_termino(indice, termino):

    if termino not in indice:

        return []

    return indice[termino].a_lista()


def mostrar_estadisticas(indice):

    total_terminos = len(indice)

    total_documentos = 0
    total_copias = 0
    total_redimensionamientos = 0

    for arreglo in indice.values():

        estadisticas = arreglo.obtener_estadisticas()

        total_documentos += estadisticas["elementos"]

        total_copias += estadisticas["copias"]

        total_redimensionamientos += (
            estadisticas["redimensionamientos"]
        )

    print("\nESTADISTICAS DEL INDICE INVERTIDO")
    print("-----------------------------------")

    print("Terminos indexados:", total_terminos)

    print("Total de publicaciones:", total_documentos)

    print("Copias realizadas:", total_copias)

    print(
        "Redimensionamientos:",
        total_redimensionamientos
    )


# -----------------------------------------
# EJECUCION PRINCIPAL
# -----------------------------------------

if __name__ == "__main__":

    import json

    with open(
        "datos/expedientes.json",
        "r",
        encoding="utf-8"
    ) as archivo:

        corpus = json.load(archivo)

    indice = construir_indice_invertido(
        corpus,
        capacidad_inicial=2
    )

    print("BUSCADOR JUDICIAL")
    print("---------------------------")

    termino = "accidente"

    documentos = buscar_termino(
        indice,
        termino
    )

    print("\nConsulta:", termino)

    print("Documentos encontrados:", documentos)

    mostrar_estadisticas(indice)
