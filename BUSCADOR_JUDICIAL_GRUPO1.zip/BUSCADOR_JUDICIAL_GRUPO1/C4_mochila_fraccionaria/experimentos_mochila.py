"""Experimento reproducible de la mochila fraccionaria C4.

Ejecutar desde la raiz:
    python -m C4_mochila_fraccionaria.experimentos_mochila

Los datos se generan antes de medir. Se reporta la mediana de 5 repeticiones,
la razon T(P)/(P log2 P) y una grafica log-log.
"""
import csv
import math
import statistics
import time
from pathlib import Path

import matplotlib.pyplot as plt

from C4_mochila_fraccionaria.mochila_fraccionaria import seleccionar_pasajes

RAIZ = Path(__file__).resolve().parent.parent
CARPETA = Path(__file__).resolve().parent / "resultados"
TAMANOS = (1000, 2000, 4000, 8000, 16000)
REPETICIONES = 5
PRESUPUESTO = 100_000_000


def generar_pasajes(cantidad):
    """Genera instancias deterministas fuera del intervalo cronometrado."""
    pasajes = []
    for i in range(cantidad):
        tokens = 10 + (i * 17) % 91
        relevancia = 1 + ((i * 29) % 500)
        pasajes.append({
            "id_pasaje": i,
            "texto": ("termino " * tokens).strip(),
            "tokens": tokens,
            "relevancia": relevancia,
        })
    return pasajes


def ejecutar_experimentos():
    filas = []
    for n in TAMANOS:
        pasajes = generar_pasajes(n)
        tiempos = []
        for _ in range(REPETICIONES):
            inicio = time.perf_counter()
            resultado = seleccionar_pasajes(pasajes, PRESUPUESTO)
            tiempos.append(time.perf_counter() - inicio)
            assert resultado["tokens_utilizados"] <= PRESUPUESTO + 1e-9
        mediana = statistics.median(tiempos)
        filas.append({
            "pasajes_P": n,
            "repeticiones": REPETICIONES,
            "mediana_s": mediana,
            "razon_T_sobre_P_log2P": mediana / (n * math.log2(n)),
            "tokens_utilizados": resultado["tokens_utilizados"],
            "relevancia_total": resultado["relevancia_total"],
        })

    CARPETA.mkdir(parents=True, exist_ok=True)
    csv_path = CARPETA / "experimentos_mochila.csv"
    with csv_path.open("w", newline="", encoding="utf-8") as f:
        writer = csv.DictWriter(f, fieldnames=list(filas[0]))
        writer.writeheader()
        writer.writerows(filas)

    fig, ax = plt.subplots(figsize=(7, 5))
    ax.loglog([r["pasajes_P"] for r in filas], [r["mediana_s"] for r in filas], "o-", label="Mediana medida")
    ax.set_xlabel("Cantidad de pasajes P")
    ax.set_ylabel("Tiempo (s)")
    ax.set_title("C4 · Mochila fraccionaria: tiempo vs. tamaño")
    ax.grid(True, which="both", alpha=0.3)
    ax.legend()
    fig.tight_layout()
    png_path = CARPETA / "C4_mochila_loglog.png"
    fig.savefig(png_path, dpi=180)
    plt.close(fig)

    print("C4 EXPERIMENTOS FINALIZADOS")
    for fila in filas:
        print(fila)
    print(f"CSV: {csv_path}")
    print(f"Grafica: {png_path}")
    return filas


if __name__ == "__main__":
    ejecutar_experimentos()
