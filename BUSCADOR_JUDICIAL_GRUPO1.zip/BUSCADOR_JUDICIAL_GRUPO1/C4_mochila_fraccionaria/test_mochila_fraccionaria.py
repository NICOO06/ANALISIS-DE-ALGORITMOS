
import pytest

from C4_mochila_fraccionaria.mochila_fraccionaria import (
    calcular_prioridad,
    extraer_pasajes,
    seleccionar_pasajes
)


# -----------------------------------------
# DATOS DE PRUEBA
# -----------------------------------------

def crear_pasajes():

    return [
        {
            "id_pasaje": 1,
            "seccion": "Hechos del caso",
            "texto": " ".join(["accidente"] * 10),
            "tokens": 10,
            "relevancia": 60
        },
        {
            "id_pasaje": 2,
            "seccion": "Fundamentos y pruebas",
            "texto": " ".join(["contrato"] * 20),
            "tokens": 20,
            "relevancia": 100
        },
        {
            "id_pasaje": 3,
            "seccion": "Decision judicial",
            "texto": " ".join(["sentencia"] * 30),
            "tokens": 30,
            "relevancia": 120
        }
    ]


# -----------------------------------------
# 1. CALCULAR PRIORIDAD
# -----------------------------------------

def test_calcular_prioridad():

    pasaje = crear_pasajes()[0]

    assert calcular_prioridad(pasaje) == 6


# -----------------------------------------
# 2. SELECCIONAR PASAJES
# -----------------------------------------

def test_seleccion_completa():

    pasajes = crear_pasajes()

    resultado = seleccionar_pasajes(
        pasajes,
        60
    )

    assert resultado["tokens_utilizados"] == 60

    assert resultado["cantidad_pasajes"] == 3


def test_orden_por_prioridad():

    pasajes = crear_pasajes()

    resultado = seleccionar_pasajes(
        pasajes,
        30
    )

    seleccionados = resultado["seleccionados"]

    assert seleccionados[0]["id_pasaje"] == 1
    assert seleccionados[1]["id_pasaje"] == 2


def test_seleccion_parcial():

    pasajes = crear_pasajes()

    resultado = seleccionar_pasajes(
        pasajes,
        15
    )

    seleccionados = resultado["seleccionados"]

    assert len(seleccionados) == 2

    assert seleccionados[0]["fraccion"] == 1

    assert seleccionados[1]["fraccion"] == 0.25

    assert resultado["tokens_utilizados"] == 15


# -----------------------------------------
# 3. VERIFICAR PRESUPUESTO
# -----------------------------------------

def test_no_superar_presupuesto():

    resultado = seleccionar_pasajes(
        crear_pasajes(),
        25
    )

    assert resultado["tokens_utilizados"] <= 25


def test_presupuesto_cero():

    resultado = seleccionar_pasajes(
        crear_pasajes(),
        0
    )

    assert resultado["seleccionados"] == []

    assert resultado["tokens_utilizados"] == 0


def test_presupuesto_suficiente():

    resultado = seleccionar_pasajes(
        crear_pasajes(),
        100
    )

    assert resultado["tokens_utilizados"] == 60


# -----------------------------------------
# 4. VERIFICAR RELEVANCIA
# -----------------------------------------

def test_relevancia_total():

    resultado = seleccionar_pasajes(
        crear_pasajes(),
        60
    )

    assert resultado["relevancia_total"] == 280


def test_fraccion_relevancia():

    resultado = seleccionar_pasajes(
        crear_pasajes(),
        15
    )

    assert resultado["relevancia_total"] == 85


# -----------------------------------------
# 5. VERIFICAR EXTRACCION DEL CORPUS
# -----------------------------------------

def test_extraer_pasajes():

    expedientes = [
        {
            "id": 1,
            "pasajes": crear_pasajes()
        }
    ]

    resultado = extraer_pasajes(expedientes)

    assert len(resultado) == 3


# -----------------------------------------
# 6. VALIDACIONES
# -----------------------------------------

def test_presupuesto_negativo():

    with pytest.raises(ValueError):

        seleccionar_pasajes(
            crear_pasajes(),
            -10
        )


def test_tokens_invalidos():

    pasajes = crear_pasajes()

    pasajes[0]["tokens"] = 0

    with pytest.raises(ValueError):

        seleccionar_pasajes(
            pasajes,
            50
        )


def test_relevancia_negativa():

    pasajes = crear_pasajes()

    pasajes[0]["relevancia"] = -5

    with pytest.raises(ValueError):

        seleccionar_pasajes(
            pasajes,
            50
        )


def test_lista_vacia():

    resultado = seleccionar_pasajes(
        [],
        100
    )

    assert resultado["seleccionados"] == []

    assert resultado["relevancia_total"] == 0


def test_expedientes_invalidos():

    with pytest.raises(ValueError):

        extraer_pasajes("expedientes")


def test_pasaje_sin_campos():

    with pytest.raises(ValueError):

        seleccionar_pasajes(
            [{"texto": "Pasaje incompleto"}],
            100
        )



def test_fragmento_parcial_respeta_tokens_asignados():
    resultado = seleccionar_pasajes(crear_pasajes(), 15)
    parcial = resultado["seleccionados"][1]
    assert len(parcial["texto_seleccionado"].split()) == parcial["tokens_asignados"]



def test_rechaza_cantidad_de_tokens_inconsistente():
    pasaje = crear_pasajes()[0].copy()
    pasaje["tokens"] = 9
    with pytest.raises(ValueError):
        seleccionar_pasajes([pasaje], 5)


def test_ordenar_por_prioridad_merge_sort_estable():
    from C4_mochila_fraccionaria.mochila_fraccionaria import ordenar_por_prioridad
    pasajes = [
        {"id_pasaje": "A", "texto": "a " * 10, "tokens": 10, "relevancia": 20},
        {"id_pasaje": "B", "texto": "b " * 5, "tokens": 5, "relevancia": 20},
        {"id_pasaje": "C", "texto": "c " * 10, "tokens": 10, "relevancia": 20},
    ]
    ordenados = ordenar_por_prioridad(pasajes)
    assert [p["id_pasaje"] for p in ordenados] == ["B", "A", "C"]


def test_mochila_fraccionaria_respeta_presupuesto_con_ordenamiento_propio():
    from C4_mochila_fraccionaria.mochila_fraccionaria import seleccionar_pasajes
    pasajes = [
        {"id_pasaje": "A", "texto": "a " * 10, "tokens": 10, "relevancia": 60},
        {"id_pasaje": "B", "texto": "b " * 20, "tokens": 20, "relevancia": 100},
        {"id_pasaje": "C", "texto": "c " * 30, "tokens": 30, "relevancia": 120},
    ]
    resultado = seleccionar_pasajes(pasajes, 50)
    assert resultado["tokens_utilizados"] <= 50 + 1e-9
    assert abs(resultado["relevancia_total"] - 240) < 1e-9
