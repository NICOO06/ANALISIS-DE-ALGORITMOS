
"""
PROYECTO: BUSCADOR JUDICIAL
COMPONENTE C4: MOCHILA FRACCIONARIA
ALGORITMO: ESTRATEGIA VORAZ (GREEDY)

Selecciona los pasajes judiciales con mayor relevancia
utilizando un presupuesto limitado de tokens.

Permite seleccionar parcialmente el ultimo pasaje.
"""

import json
import math
from pathlib import Path


# -------------------------------------------------
# 1. VALIDAR LOS DATOS DE ENTRADA
# -------------------------------------------------

def validar_pasaje(pasaje):

    if not isinstance(pasaje, dict):
        raise ValueError("Cada pasaje debe ser un diccionario.")

    campos = ["id_pasaje", "texto", "tokens", "relevancia"]

    for campo in campos:

        if campo not in pasaje:
            raise ValueError(
                f"El pasaje no contiene el campo: {campo}"
            )

    tokens = pasaje["tokens"]
    relevancia = pasaje["relevancia"]

    if (
        isinstance(tokens, bool)
        or not isinstance(tokens, int)
        or tokens <= 0
    ):
        raise ValueError("Los tokens deben ser un entero positivo.")

    if (
        isinstance(relevancia, bool)
        or not isinstance(relevancia, (int, float))
        or not math.isfinite(relevancia)
        or relevancia < 0
    ):
        raise ValueError("La relevancia debe ser un numero no negativo.")

    if not isinstance(pasaje["texto"], str):
        raise ValueError("El texto del pasaje debe ser una cadena.")

    if len(pasaje["texto"].split()) != tokens:
        raise ValueError(
            "El campo 'tokens' debe coincidir con la cantidad de palabras "
            "separadas por espacios del texto."
        )


# -------------------------------------------------
# 2. CALCULAR PRIORIDAD DE CADA PASAJE
# -------------------------------------------------

def calcular_prioridad(pasaje):

    validar_pasaje(pasaje)

    return pasaje["relevancia"] / pasaje["tokens"]


# -------------------------------------------------
# 3. EXTRAER PASAJES DE LOS EXPEDIENTES
# -------------------------------------------------

def extraer_pasajes(expedientes):

    if not isinstance(expedientes, list):
        raise ValueError("Los expedientes deben estar en una lista.")

    pasajes = []

    for expediente in expedientes:

        if not isinstance(expediente, dict):
            raise ValueError("Cada expediente debe ser un diccionario.")

        lista_pasajes = expediente.get("pasajes")

        if not isinstance(lista_pasajes, list):
            raise ValueError(
                "Cada expediente debe contener una lista de pasajes."
            )

        for pasaje in lista_pasajes:

            validar_pasaje(pasaje)
            pasajes.append(pasaje)

    return pasajes



def ordenar_por_prioridad(pasajes):
    """Ordena por relevancia/token usando Merge Sort propio y estable.

    No utiliza sorted() ni list.sort() para el núcleo del algoritmo.
    En empates conserva el orden original de entrada.
    """
    elementos = [
        (calcular_prioridad(pasaje), indice, pasaje)
        for indice, pasaje in enumerate(pasajes)
    ]
    auxiliar = [None] * len(elementos)

    def mezclar(inicio, medio, fin):
        i, j, k = inicio, medio, inicio
        while i < medio and j < fin:
            prioridad_i, indice_i, _ = elementos[i]
            prioridad_j, indice_j, _ = elementos[j]
            # Mayor densidad primero; en empate, menor índice primero.
            if (prioridad_i > prioridad_j or
                (prioridad_i == prioridad_j and indice_i < indice_j)):
                auxiliar[k] = elementos[i]
                i += 1
            else:
                auxiliar[k] = elementos[j]
                j += 1
            k += 1
        while i < medio:
            auxiliar[k] = elementos[i]
            i += 1
            k += 1
        while j < fin:
            auxiliar[k] = elementos[j]
            j += 1
            k += 1
        for posicion in range(inicio, fin):
            elementos[posicion] = auxiliar[posicion]

    def merge_sort(inicio, fin):
        if fin - inicio <= 1:
            return
        medio = (inicio + fin) // 2
        merge_sort(inicio, medio)
        merge_sort(medio, fin)
        mezclar(inicio, medio, fin)

    merge_sort(0, len(elementos))
    return [pasaje for _, _, pasaje in elementos]

# -------------------------------------------------
# 4. SELECCIONAR PASAJES CON MOCHILA FRACCIONARIA
# -------------------------------------------------

def seleccionar_pasajes(pasajes, presupuesto_tokens):

    if (
        isinstance(presupuesto_tokens, bool)
        or not isinstance(presupuesto_tokens, (int, float))
        or not math.isfinite(presupuesto_tokens)
        or presupuesto_tokens < 0
    ):
        raise ValueError("El presupuesto debe ser un numero no negativo.")

    if not isinstance(pasajes, list):
        raise ValueError("Los pasajes deben estar en una lista.")

    for pasaje in pasajes:
        validar_pasaje(pasaje)

    # Ordenar por densidad con Merge Sort propio (Θ(P log P)).
    ordenados = ordenar_por_prioridad(pasajes)

    presupuesto_restante = presupuesto_tokens
    relevancia_total = 0
    tokens_utilizados = 0

    seleccionados = []

    # Recorrer los pasajes ordenados.
    for pasaje in ordenados:

        if presupuesto_restante <= 0:
            break

        tokens_disponibles = pasaje["tokens"]

        # Los tokens son unidades indivisibles en el texto. Si el presupuesto
        # restante no alcanza para un token completo, no se selecciona otro.
        tokens_asignados = min(
            tokens_disponibles,
            int(math.floor(presupuesto_restante)),
        )

        if tokens_asignados <= 0:
            break

        # La fraccion seleccionada se calcula sobre tokens reales, no sobre
        # caracteres aproximados del texto.
        fraccion = tokens_asignados / tokens_disponibles
        relevancia_obtenida = pasaje["relevancia"] * fraccion

        palabras = pasaje["texto"].split()
        texto_seleccionado = " ".join(palabras[:tokens_asignados])

        resultado = pasaje.copy()

        resultado.update({
            "prioridad": calcular_prioridad(pasaje),
            "fraccion": fraccion,
            "tokens_asignados": tokens_asignados,
            "relevancia_obtenida": relevancia_obtenida,
            "texto_seleccionado": texto_seleccionado
        })

        seleccionados.append(resultado)

        tokens_utilizados += tokens_asignados
        relevancia_total += relevancia_obtenida

        presupuesto_restante -= tokens_asignados

    return {
        "seleccionados": seleccionados,
        "presupuesto": presupuesto_tokens,
        "tokens_utilizados": tokens_utilizados,
        "presupuesto_restante": max(0, presupuesto_restante),
        "relevancia_total": relevancia_total,
        "cantidad_pasajes": len(seleccionados)
    }


# -------------------------------------------------
# 5. MOSTRAR RESULTADOS
# -------------------------------------------------

def mostrar_resultados(resultado):

    print("\n" + "=" * 55)
    print("RESULTADOS DE LA MOCHILA FRACCIONARIA")
    print("=" * 55)

    print("Presupuesto:", resultado["presupuesto"])
    print("Tokens utilizados:", round(resultado["tokens_utilizados"], 2))
    print("Tokens restantes:", round(resultado["presupuesto_restante"], 2))
    print("Relevancia total:", round(resultado["relevancia_total"], 2))
    print("Pasajes seleccionados:", resultado["cantidad_pasajes"])

    print("\nDETALLE DE PASAJES SELECCIONADOS")
    print("-" * 55)

    for pasaje in resultado["seleccionados"]:

        print(
            f"\nID: {pasaje['id_pasaje']}"
        )

        print(
            f"Seccion: {pasaje.get('seccion', 'Sin seccion')}"
        )

        print(
            f"Prioridad: {pasaje['prioridad']:.4f}"
        )

        print(
            f"Fraccion seleccionada: {pasaje['fraccion']:.2%}"
        )

        print(
            f"Tokens utilizados: {pasaje['tokens_asignados']:.2f}"
        )

        print(
            f"Relevancia obtenida: {pasaje['relevancia_obtenida']:.2f}"
        )

        print(
            f"Texto: {pasaje['texto_seleccionado'][:120]}..."
        )


# -------------------------------------------------
# 6. EJEMPLO DE CONTRAEJEMPLO MOCHILA 0/1
# -------------------------------------------------

def ejecutar_ejemplo():

    print("\nCONTRAEJEMPLO: MOCHILA FRACCIONARIA VS 0/1")

    elementos = [
        {"nombre": "A", "tokens": 10, "relevancia": 60},
        {"nombre": "B", "tokens": 20, "relevancia": 100},
        {"nombre": "C", "tokens": 30, "relevancia": 120}
    ]

    presupuesto = 50

    print("\nElementos disponibles:")
    for elemento in elementos:
        print(elemento)

    print("\nPresupuesto:", presupuesto)

    resultado = seleccionar_pasajes(
        [
            {
                "id_pasaje": elemento["nombre"],
                "texto": " ".join([elemento["nombre"]] * elemento["tokens"]),
                "tokens": elemento["tokens"],
                "relevancia": elemento["relevancia"]
            }
            for elemento in elementos
        ],
        presupuesto
    )

    print(
        "\nResultado mochila fraccionaria:",
        round(resultado["relevancia_total"], 2)
    )

    # En mochila 0/1 no se permite dividir elementos.
    # Probamos todas las combinaciones posibles.
    mejor_01 = 0

    for mascara in range(1 << len(elementos)):

        tokens = 0
        relevancia = 0

        for i, elemento in enumerate(elementos):

            if mascara & (1 << i):

                tokens += elemento["tokens"]
                relevancia += elemento["relevancia"]

        if tokens <= presupuesto:

            mejor_01 = max(mejor_01, relevancia)

    print(
        "Resultado mochila 0/1:",
        mejor_01
    )

    print(
        "\nLa mochila fraccionaria permite aprovechar "
        "una parte del ultimo elemento."
    )


# -------------------------------------------------
# 7. EJECUCION PRINCIPAL
# -------------------------------------------------

if __name__ == "__main__":

    ruta_corpus = (
        Path(__file__).resolve().parent.parent
        / "datos"
        / "expedientes.json"
    )

    print("=" * 55)
    print("BUSCADOR JUDICIAL - MOCHILA FRACCIONARIA")
    print("=" * 55)

    if not ruta_corpus.exists():

        raise FileNotFoundError(
            f"No se encontro el corpus: {ruta_corpus}"
        )

    with open(ruta_corpus, "r", encoding="utf-8") as archivo:

        expedientes = json.load(archivo)

    pasajes = extraer_pasajes(expedientes)

    print("\nCorpus cargado correctamente.")
    print("Expedientes:", len(expedientes))
    print("Pasajes disponibles:", len(pasajes))

    presupuesto = 1000

    resultado = seleccionar_pasajes(
        pasajes,
        presupuesto
    )

    mostrar_resultados(resultado)

    ejecutar_ejemplo()
