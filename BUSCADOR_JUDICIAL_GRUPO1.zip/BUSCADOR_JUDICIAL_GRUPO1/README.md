# BUSCADOR JUDICIAL — GRUPO 1

Proyecto académico de **Análisis de Algoritmos (SIST0175)**. Integra seis componentes para construir un índice invertido sobre un corpus sintético de expedientes, consultar por términos y fechas, sugerir correcciones ortográficas y seleccionar pasajes dentro de un presupuesto de tokens.

> **Alcance:** los 100 expedientes incluidos son sintéticos. El proyecto es un prototipo académico y no constituye asesoría jurídica ni procesa expedientes reales. C6 es una demostración numérica independiente de atención; no es un modelo semántico ni un sistema de embeddings conectado al buscador.

## Entregable técnico

El informe técnico final está en `docs/INFORME_TECNICO_FINAL_GRUPO1.pdf`. Antes de publicar, los tres integrantes deben validar el reparto real en `docs/REPARTO_TRABAJO_PENDIENTE.md`.

## 1. Componentes

| Componente | Algoritmo / estructura | Uso |
|---|---|---|
| C1 | Merge Sort | Ordena pares (término, documento) y colecciones auxiliares sin usar `sorted()` ni `list.sort()` en el núcleo. |
| C2 | Arreglo dinámico con duplicación | Almacena listas de posteo del índice invertido; inserción amortizada O(1). |
| C3 | Programación dinámica: Levenshtein + Trie | Calcula distancias de edición y poda prefijos que superan el umbral de distancia. |
| C4 | Voraz: mochila fraccionaria | Maximiza relevancia bajo presupuesto de tokens; ordena por relevancia/token con Merge Sort del proyecto. |
| C5 | Árbol B+ y disco simulado | Indexa fechas y soporta búsqueda puntual y por rango con conteo de E/S y búfer LRU limitado por M/B. |
| C6 | Atención exacta vs. atención por bloques | Compara el resultado numérico y el uso de memoria de ambas implementaciones. |

## 2. Estructura

```text
BUSCADOR_JUDICIAL_GRUPO1/
├── C1_merge_sort/
├── C2_arreglo_dinamico/
├── C3_levenshtein/
├── C4_mochila_fraccionaria/
│   └── resultados/
├── C5_arbol_b_mas/
├── C6_atencion/
│   ├── graficas/
│   └── resultados/
├── datos/
├── experimentos/
├── experimentos_graficas/
├── pruebas/
├── docs/
├── main.py
├── requirements.txt
└── README.md
```

## 3. Requisitos e instalación

- Python 3.10 o superior.
- Dependencias listadas en `requirements.txt` (NumPy, Matplotlib y Pytest).

Windows PowerShell, desde la carpeta raíz:

```powershell
python -m venv .venv
.\.venv\Scripts\Activate.ps1
python -m pip install --upgrade pip
python -m pip install -r requirements.txt
```

En Linux/macOS:

```bash
python -m venv .venv
source .venv/bin/activate
python -m pip install --upgrade pip
python -m pip install -r requirements.txt
```

## 4. Ejecutar el buscador

```bash
python main.py
```

Opciones del menú:

1. Buscar expedientes por palabras (intersección AND; todos los términos deben aparecer).
2. Buscar por rango de fechas mediante el árbol B+.
3. Seleccionar pasajes relevantes mediante mochila fraccionaria.
4. Ejecutar demostración numérica de C6.
5. Consultar estadísticas.
0. Salir.

El corpus predeterminado está en `datos/expedientes.json`. El generador se encuentra en `datos/generador.py`.

## 5. Ejecutar pruebas

Desde la raíz:

```bash
python -m pytest -v
```

Pruebas de integración:

```bash
python -m pytest pruebas/test_integracion.py -v
```

La revisión de entrega se ejecutó en Python 3.13.5: **126 pruebas aprobadas**. El resultado puede variar si se modifican archivos, dependencias o entorno; vuelve a ejecutar la suite antes de entregar.

## 6. Experimentos reproducibles

Cada experimento genera o prepara los datos antes de iniciar el cronómetro, usa `time.perf_counter()` y reporta medianas de cinco repeticiones cuando aplica.

| Componentes | Comando | Salidas principales |
|---|---|---|
| C1, C2, C3 | `python experimentos_optimizacion.py` | `resultados_optimizacion.csv`, `experimentos_graficas/` |
| C4 | `python -m C4_mochila_fraccionaria.experimentos_mochila` | `C4_mochila_fraccionaria/resultados/experimentos_mochila.csv` y gráfica log-log |
| C5 | `python -m C5_arbol_b_mas.experimentos_b_mas` | `C5_arbol_b_mas/resultados_b_mas.csv` con E/S predichas y contadas |
| C6 | `python -m C6_atencion.experimentos_atencion` | CSV y gráficas en `C6_atencion/resultados/` y `C6_atencion/graficas/` |

También se encuentra una guía de ejecución en `experimentos/README.md`.

### Parámetros documentados de C5

El experimento C5 usa orden `f=8`, tamaño de bloque `B=4096` bytes y memoria principal simulada `M=16384` bytes. El búfer LRU tiene `M/B=4` marcos. Como una hoja puede alojar hasta siete claves y el mínimo de ocupación usado en la cota es cuatro, la memoria equivale a 28 registros de hoja; el menor N ensayado es 1000, de modo que 28 ≤ 1000/20. El contador mide lecturas/escrituras físicas del archivo simulado; los accesos servidos desde el búfer no se contabilizan como E/S de disco.

Para C5 se reportan cotas superiores conservadoras para inserción y rango. La altura `h` se aproxima con `ceil(log_f N)+1`; búsqueda puntual predice `h` lecturas. Para rango con `R` registros se usa `h + ceil(R / ocupación_mínima_hoja)` como cota superior de lecturas. Las lecturas/escrituras reales se obtienen del disco simulado con búfer limitado.

## 7. Análisis y decisiones importantes

- **C1:** Merge Sort con recurrencia `T(n)=2T(n/2)+Θ(n)`; caso 2 del Teorema Maestro y tiempo `Θ(n log n)`.
- **C2:** duplicación de capacidad. Cada inserción cuesta `Θ(1)` salvo redimensionamiento `Θ(n)`; el método contable usa tres créditos por inserción y mantiene saldo no negativo.
- **C3:** Levenshtein usa dos filas para el cálculo normal (`Θ(mn)` tiempo y `Θ(min(m,n))` espacio auxiliar). El Trie comparte prefijos y poda cuando el mínimo de la fila supera el umbral. La búsqueda acotada cuesta `O(Pm)`, donde P es el número de nodos visitados.
- **C4:** la mochila fraccionaria es óptima por el orden descendente de densidad `relevancia/tokens`, demostrado por intercambio. El contraejemplo incluido muestra que esa misma regla no garantiza el óptimo para mochila 0/1. El ordenamiento es Merge Sort propio (`Θ(P log P)`), no `sorted()`.
- **C5:** un nodo ocupa un bloque del archivo simulado. El búfer LRU limita los bloques residentes a `floor(M/B)`. La búsqueda puntual es `Θ(log_f N)` E/S en el modelo sin aciertos previos; el rango es `O(log_f N + R/B_leaf)`.
- **C6:** ambas variantes realizan `Θ(MN(d+dv))` operaciones (si `M=N` y `dv=d`, `Θ(N²d)`). La atención exacta materializa la matriz de puntuaciones; la versión por bloques mantiene acumuladores de softmax en línea y reduce memoria temporal. La equivalencia se verifica numéricamente con tolerancias `rtol=1e-10`, `atol=1e-12`.

**Nota de alcance de C4:** la guía general menciona análisis probabilístico o poda para algunas estrategias C4, pero el caso específico del Grupo 1 asigna mochila fraccionaria y solicita prueba voraz y contraejemplo 0/1. Se sigue el algoritmo específico asignado al grupo; no se presenta aleatorización ficticia.

## 8. Uso de herramientas de IA

Se utilizó ChatGPT como apoyo para revisar requisitos, explicar complejidades, detectar defectos, proponer pruebas y experimentos, mejorar documentación y revisar redacción. El equipo debe revisar, ejecutar y comprender los cambios entregados. La responsabilidad académica sobre el código, los resultados y la sustentación corresponde a los integrantes.

## 9. Integrantes

- Nicolás Vargas
- Santiago Mejía
- Bryan Rodríguez

El reparto específico de implementación, pruebas, integración y documentación debe completarse con las contribuciones reales del equipo en `docs/REPARTO_TRABAJO_PENDIENTE.md`; no se asignaron tareas individuales sin confirmación de sus autores.

## 10. Referencias

- Cormen, T. H., Leiserson, C. E., Rivest, R. L., & Stein, C. (2022). *Introduction to Algorithms* (4th ed.). MIT Press.
- Kleinberg, J., & Tardos, É. (2006). *Algorithm Design*. Pearson.
- Knuth, D. E. (1998). *The Art of Computer Programming, Volume 3: Sorting and Searching* (2nd ed.). Addison-Wesley.
- OpenAI. (2026). *ChatGPT* [asistente de IA utilizado como apoyo de revisión y documentación]. https://chatgpt.com/
- Rodríguez Martínez, J. D. (2026). *Proyecto Final Integrador – Análisis de Algoritmos (SIST0175)*. Guía del proyecto, Universidad Sergio Arboleda.


## 7. Protocolo reproducible y entorno de revisión

Se validó esta versión en Python 3.13.5. Para repetir las pruebas y experimentos desde la raíz:

```bash
python -m pip install -r requirements.txt
python -m pytest -q
python experimentos_optimizacion.py
python -m C4_mochila_fraccionaria.experimentos_mochila
python -m C5_arbol_b_mas.experimentos_b_mas
python -m C6_atencion.experimentos_atencion
```

El resultado de la ejecución de revisión fue **126 pruebas aprobadas**. Las mediciones pueden variar entre equipos; los CSV y gráficas se regeneran con los comandos anteriores. Se recomienda conservar la salida de consola junto con los CSV al hacer una nueva validación.

## 8. Declaración de uso de herramientas de IA

Se utilizó ChatGPT como apoyo para revisar la guía del proyecto, identificar aspectos por completar, depurar errores, contrastar los resultados de pruebas, proponer experimentos reproducibles y preparar documentación técnica. Las decisiones, revisión final, comprensión y responsabilidad académica sobre el código y los resultados corresponden a los integrantes del equipo. La declaración no implica que la herramienta sea autora del proyecto.

## 9. Reparto de trabajo

El reparto nominal de componentes y actividades debe ser confirmado por Nicolás Vargas, Santiago Mejía y Bryan Rodríguez antes de la entrega. No se atribuyen tareas individuales sin confirmación del equipo. Completar `docs/REPARTO_TRABAJO_PENDIENTE.md`.

