"""Experimentos reproducibles C1, C2 y C3 - Buscador Judicial Grupo 1.

Ejecutar desde la raiz del proyecto:
    python experimentos_optimizacion.py

Genera resultados_optimizacion.csv y graficas PNG en experimentos_graficas/.
Los datos se preparan antes de medir. Cada punto usa cinco repeticiones y
se reporta la mediana. Los tiempos dependen del equipo de ejecucion.
"""
from __future__ import annotations

import csv
import random
import statistics
import time
import tracemalloc
from pathlib import Path

import matplotlib.pyplot as plt

from C1_merge_sort.merge_sort import merge_sort
from C2_arreglo_dinamico.arreglo_dinamico import ArregloDinamico
from C3_levenshtein.levenshtein import construir_tabla, distancia_levenshtein

ROOT = Path(__file__).resolve().parent
OUT = ROOT / "resultados_optimizacion.csv"
GRAPH_DIR = ROOT / "experimentos_graficas"
REPS = 5


def median_time(fn, reps=REPS):
    samples = []
    for _ in range(reps):
        start = time.perf_counter()
        fn()
        samples.append(time.perf_counter() - start)
    return statistics.median(samples)


def peak_memory(fn):
    tracemalloc.start()
    try:
        fn()
        _, peak = tracemalloc.get_traced_memory()
        return peak
    finally:
        tracemalloc.stop()


def run_c1(rows):
    ns, times, normalized = [], [], []
    rng = random.Random(20261117)
    for n in (1000, 2000, 4000, 8000, 16000):
        data = [(f"termino_{rng.randrange(0, n // 4):06d}", i) for i in range(n)]
        elapsed = median_time(lambda: merge_sort(data))
        ns.append(n); times.append(elapsed)
        normalized.append(elapsed / (n * (n.bit_length() - 1)))
        rows.append({"componente":"C1", "n":"pares", "tamano":n,
                     "tiempo_mediana_s":elapsed, "tiempo_normalizado":normalized[-1],
                     "costo_real_unidades":"", "copias":"", "redimensiones":"",
                     "creditos_finales":"", "memoria_pico_bytes":"", "repeticiones":REPS})
    plt.figure(); plt.loglog(ns, times, marker="o", label="Tiempo mediano")
    plt.loglog(ns, [times[0]*(n/ns[0])*((n.bit_length()-1)/(ns[0].bit_length()-1)) for n in ns],
               linestyle="--", label="Referencia n log2(n)")
    plt.xlabel("Cantidad de pares n"); plt.ylabel("Tiempo (s)"); plt.title("C1 - Merge Sort")
    plt.legend(); plt.tight_layout(); plt.savefig(GRAPH_DIR / "C1_merge_sort.png", dpi=160); plt.close()
    return ns, times


def run_c2(rows):
    ns, actual, amortized, copies, resizes, credits = [], [], [], [], [], []
    for n in (1000, 2000, 4000, 8000, 16000):
        def build():
            arr = ArregloDinamico(capacidad_inicial=2)
            for value in range(n):
                arr.insertar(value)
            return arr
        elapsed = median_time(build)
        arr = build()
        stats = arr.obtener_estadisticas()
        real = stats["costo_real_inserciones"]
        budget = stats["costo_amortizado_acumulado"]
        ns.append(n); actual.append(real); amortized.append(budget)
        copies.append(stats["copias"]); resizes.append(stats["redimensionamientos"])
        credits.append(stats["creditos_disponibles"])
        rows.append({"componente":"C2", "n":"inserciones", "tamano":n,
                     "tiempo_mediana_s":elapsed, "tiempo_normalizado":real/n,
                     "costo_real_unidades":real, "copias":stats["copias"],
                     "redimensiones":stats["redimensionamientos"],
                     "creditos_finales":stats["creditos_disponibles"],
                     "memoria_pico_bytes":"", "repeticiones":REPS})
        assert stats["creditos_disponibles"] >= 0
        assert real <= budget
        assert budget == 3 * n
    plt.figure(); plt.plot(ns, actual, marker="o", label="Costo real (inserciones + copias)")
    plt.plot(ns, amortized, marker="s", linestyle="--", label="Presupuesto contable 3n")
    plt.xlabel("Cantidad de inserciones n"); plt.ylabel("Unidades de costo")
    plt.title("C2 - Costo acumulado y presupuesto amortizado"); plt.legend(); plt.tight_layout()
    plt.savefig(GRAPH_DIR / "C2_costo_amortizado.png", dpi=160); plt.close()
    plt.figure(); plt.plot(ns, [c/n for c,n in zip(copies,ns)], marker="o", label="Copias por insercion")
    plt.plot(ns, [r for r in resizes], marker="s", label="Redimensionamientos")
    plt.xlabel("Cantidad de inserciones n"); plt.ylabel("Conteo")
    plt.title("C2 - Copias y redimensionamientos"); plt.legend(); plt.tight_layout()
    plt.savefig(GRAPH_DIR / "C2_operaciones.png", dpi=160); plt.close()
    return ns, actual, amortized, copies, resizes, credits


def run_c3(rows):
    ns, full_times, two_times, full_mem, two_mem = [], [], [], [], []
    for length in (32, 64, 128, 256, 512):
        a = "a" * length
        b = "a" * (length - 1) + "b"
        t_full = median_time(lambda: construir_tabla(a, b))
        t_two = median_time(lambda: distancia_levenshtein(a, b))
        m_full = peak_memory(lambda: construir_tabla(a, b))
        m_two = peak_memory(lambda: distancia_levenshtein(a, b))
        assert construir_tabla(a, b)[-1][-1] == distancia_levenshtein(a, b)
        ns.append(length); full_times.append(t_full); two_times.append(t_two)
        full_mem.append(m_full); two_mem.append(m_two)
        rows.append({"componente":"C3", "n":"longitud_m_n", "tamano":length,
                     "tiempo_mediana_s":t_two, "tiempo_normalizado":t_two/(length*length),
                     "costo_real_unidades":"", "copias":"", "redimensiones":"",
                     "creditos_finales":"", "memoria_pico_bytes":m_two, "repeticiones":REPS})
    plt.figure(); plt.loglog(ns, full_times, marker="o", label="Matriz completa")
    plt.loglog(ns, two_times, marker="s", label="Dos filas")
    plt.xlabel("Longitud de cada cadena"); plt.ylabel("Tiempo mediano (s)")
    plt.title("C3 - Tiempo de Levenshtein"); plt.legend(); plt.tight_layout()
    plt.savefig(GRAPH_DIR / "C3_tiempo.png", dpi=160); plt.close()
    plt.figure(); plt.loglog(ns, full_mem, marker="o", label="Matriz completa")
    plt.loglog(ns, two_mem, marker="s", label="Dos filas")
    plt.xlabel("Longitud de cada cadena"); plt.ylabel("Memoria pico (bytes)")
    plt.title("C3 - Memoria de Levenshtein"); plt.legend(); plt.tight_layout()
    plt.savefig(GRAPH_DIR / "C3_memoria.png", dpi=160); plt.close()
    return ns, full_times, two_times, full_mem, two_mem


def main():
    GRAPH_DIR.mkdir(exist_ok=True)
    rows = []
    c1 = run_c1(rows)
    c2 = run_c2(rows)
    c3 = run_c3(rows)
    fields = ["componente", "n", "tamano", "tiempo_mediana_s", "tiempo_normalizado",
              "costo_real_unidades", "copias", "redimensiones", "creditos_finales",
              "memoria_pico_bytes", "repeticiones"]
    with OUT.open("w", newline="", encoding="utf-8") as f:
        writer = csv.DictWriter(f, fieldnames=fields); writer.writeheader(); writer.writerows(rows)
    print(f"CSV: {OUT}")
    print(f"Graficas: {GRAPH_DIR}")
    print("C2 - resumen (n, costo real, presupuesto 3n, copias, redimensiones, creditos):")
    for n, real, budget, cp, rz, cr in zip(c2[0], c2[1], c2[2], c2[3], c2[4], c2[5]):
        print(f"{n:>6} | {real:>6} | {budget:>6} | {cp:>6} | {rz:>3} | {cr:>6}")
    print("C3 - memoria pico (longitud, matriz completa, dos filas):")
    for n, mf, mt in zip(c3[0], c3[3], c3[4]):
        print(f"{n:>4} | {mf:>9} | {mt:>9} | reduccion={1-mt/mf:.1%}")
    print("Experimentos terminados. Tiempos medidos en este entorno; repetir en el equipo de sustentacion.")

if __name__ == "__main__":
    main()
