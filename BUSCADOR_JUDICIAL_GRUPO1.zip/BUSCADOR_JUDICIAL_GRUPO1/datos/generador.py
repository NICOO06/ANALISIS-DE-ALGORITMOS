
"""
PROYECTO: BUSCADOR JUDICIAL
MODULO: Generador de expedientes

Descripcion:
Genera expedientes judiciales sinteticos para
realizar pruebas con los algoritmos del proyecto.

Autor: Grupo 1
"""

import json
import random
from datetime import date, timedelta
from pathlib import Path


# -----------------------------------------
# 1. DATOS PARA GENERAR LOS EXPEDIENTES
# -----------------------------------------

TIPOS_CASO = [
    "responsabilidad civil",
    "accidente de transito",
    "derecho laboral",
    "derecho penal",
    "derecho comercial",
    "derecho administrativo"
]

PALABRAS = [
    "accidente", "responsabilidad", "contrato",
    "demanda", "sentencia", "condena",
    "derecho", "obligacion", "perjuicio",
    "indemnizacion", "transito", "laboral",
    "judicial", "prueba", "demandante",
    "demandado", "reparacion", "incumplimiento",
    "recurso", "juzgado", "evidencia",
    "testimonio", "resolucion", "proceso"
]


# -----------------------------------------
# 2. GENERAR UN EXPEDIENTE
# -----------------------------------------

def generar_expediente(id_expediente, generador):

    tipo = generador.choice(TIPOS_CASO)

    fecha_inicial = date(2020, 1, 1)

    fecha = fecha_inicial + timedelta(
        days=generador.randint(0, 2000)
    )

    pasajes = []

    secciones = [
        "Hechos del caso",
        "Fundamentos y pruebas",
        "Decision judicial"
    ]

    for numero, seccion in enumerate(secciones, start=1):

        palabras = generador.choices(PALABRAS, k=30)

        texto = (
            seccion
            + ". En el expediente se analiza un caso de "
            + tipo
            + ". "
            + " ".join(palabras)
            + "."
        )

        pasaje = {
            "id_pasaje": numero,
            "seccion": seccion,
            "texto": texto,
            "tokens": len(texto.split()),
            "relevancia": generador.randint(1, 100)
        }

        pasajes.append(pasaje)

    texto_completo = " ".join(
        pasaje["texto"] for pasaje in pasajes
    )

    expediente = {
        "id": id_expediente,
        "fecha": fecha.isoformat(),
        "tipo": tipo,
        "titulo": "Expediente sobre " + tipo,
        "texto": texto_completo,
        "pasajes": pasajes
    }

    return expediente


# -----------------------------------------
# 3. GENERAR EL CORPUS COMPLETO
# -----------------------------------------

def generar_corpus(cantidad=100, semilla=42):

    if (
        isinstance(cantidad, bool)
        or not isinstance(cantidad, int)
        or cantidad < 1
    ):
        raise ValueError(
            "La cantidad debe ser un entero mayor que cero."
        )

    generador = random.Random(semilla)

    expedientes = []

    for numero in range(1, cantidad + 1):

        expediente = generar_expediente(
            numero,
            generador
        )

        expedientes.append(expediente)

    return expedientes


# -----------------------------------------
# 4. GUARDAR LOS EXPEDIENTES EN JSON
# -----------------------------------------

def guardar_corpus(cantidad=100, semilla=42):

    expedientes = generar_corpus(cantidad, semilla)

    ruta = Path(__file__).resolve().parent

    archivo = ruta / "expedientes.json"

    with open(archivo, "w", encoding="utf-8") as documento:

        json.dump(
            expedientes,
            documento,
            ensure_ascii=False,
            indent=4
        )

    return archivo


# -----------------------------------------
# 5. EJECUCION PRINCIPAL
# -----------------------------------------

if __name__ == "__main__":

    print("----------------------------------")
    print(" GENERADOR DE EXPEDIENTES JUDICIALES")
    print("----------------------------------")

    archivo_generado = guardar_corpus(
        cantidad=100,
        semilla=42
    )

    print("\nCorpus generado correctamente.")

    print("Cantidad de expedientes: 100")

    print("Archivo:", archivo_generado)

    print("\nCada expediente contiene 3 pasajes.")

    print("----------------------------------")
