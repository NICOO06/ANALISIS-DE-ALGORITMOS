
"""
PROYECTO: BUSCADOR JUDICIAL
COMPONENTE C6: SISTEMA DE ATENCION
ALGORITMOS:
1. Atencion exacta.
2. Atencion por bloques (Tiled Attention).
3. Softmax en linea para estabilidad numerica.
"""

import numpy as np
from math import sqrt


# =====================================================
# 1. VALIDACION DE ENTRADAS
# =====================================================

def validar_entradas(Q, K, V):
    """
    Verifica dimensiones y valores de las matrices.

    Q: consultas       (M, d)
    K: claves          (N, d)
    V: valores         (N, dv)
    """

    try:
        Q = np.asarray(Q, dtype=np.float64)
        K = np.asarray(K, dtype=np.float64)
        V = np.asarray(V, dtype=np.float64)
    except (TypeError, ValueError) as error:
        raise ValueError("Q, K y V deben contener valores numericos.") from error

    if Q.ndim != 2 or K.ndim != 2 or V.ndim != 2:
        raise ValueError("Q, K y V deben ser matrices 2D.")

    if Q.shape[0] == 0 or K.shape[0] == 0:
        raise ValueError("Las matrices Q y K no pueden estar vacias.")

    if Q.shape[1] != K.shape[1]:
        raise ValueError("Q y K deben tener la misma dimension.")

    if K.shape[0] != V.shape[0]:
        raise ValueError("K y V deben tener la misma cantidad de filas.")

    if Q.shape[1] == 0 or V.shape[1] == 0:
        raise ValueError("Las dimensiones internas deben ser positivas.")

    if not (
        np.all(np.isfinite(Q))
        and np.all(np.isfinite(K))
        and np.all(np.isfinite(V))
    ):
        raise ValueError("Las matrices no pueden contener NaN o infinito.")

    return Q, K, V


# =====================================================
# 2. FUNCION SOFTMAX NUMERICAMENTE ESTABLE
# =====================================================

def softmax(matriz):
    """
    Calcula Softmax por filas.
    Resta el maximo para evitar desbordamientos numericos.
    """

    matriz = np.asarray(matriz, dtype=np.float64)
    if matriz.ndim != 2 or matriz.shape[1] == 0:
        raise ValueError("Softmax requiere una matriz 2D con columnas.")
    if not np.all(np.isfinite(matriz)):
        raise ValueError("Softmax no admite valores NaN o infinitos.")

    maximos = np.max(matriz, axis=1, keepdims=True)

    exponenciales = np.exp(matriz - maximos)

    denominador = np.sum(
        exponenciales,
        axis=1,
        keepdims=True
    )

    return exponenciales / denominador


# =====================================================
# 3. ATENCION EXACTA
# =====================================================

def atencion_exacta(Q, K, V):
    """
    Implementacion tradicional de atencion.

    Calcula:

    Attention(Q,K,V) = Softmax(QK^T / sqrt(d))V

    Complejidad temporal: Theta(M*N*(d+dv)).
    Memoria auxiliar dominante: Theta(M*N + M*dv), incluyendo la salida.
    """

    Q, K, V = validar_entradas(Q, K, V)

    d = Q.shape[1]

    # 1. Calcular matriz de puntuaciones.
    with np.errstate(over="ignore", invalid="ignore"):
        puntuaciones = (Q @ K.T) / sqrt(d)

    # 2. Aplicar Softmax.
    probabilidades = softmax(puntuaciones)

    # 3. Multiplicar por los valores.
    resultado = probabilidades @ V

    if not np.all(np.isfinite(resultado)):
        raise ValueError("El resultado de atencion excede el rango numerico.")

    return resultado


# =====================================================
# 4. ATENCION POR BLOQUES (TILED ATTENTION)
# =====================================================

def atencion_bloques(Q, K, V, bloque_consultas=64,
                     bloque_claves=64):
    """
    Implementacion de atencion por bloques.

    Utiliza Softmax en linea para evitar almacenar
    la matriz completa de puntuaciones.

    Complejidad temporal: Theta(M*N*(d+dv)).
    Memoria de trabajo, sin contar Q, K y V de entrada:
    Theta(M*dv + Bq*Bk + Bq*d + Bk*dv + Bq*dv).
    El termino M*dv corresponde a la matriz de salida.
    """

    Q, K, V = validar_entradas(Q, K, V)

    if (
        isinstance(bloque_consultas, bool)
        or not isinstance(bloque_consultas, int)
        or isinstance(bloque_claves, bool)
        or not isinstance(bloque_claves, int)
        or bloque_consultas < 1
        or bloque_claves < 1
    ):
        raise ValueError("Los tamanos de bloque deben ser enteros positivos.")

    M, d = Q.shape
    N = K.shape[0]
    dv = V.shape[1]

    escala = sqrt(d)

    # Matriz de salida.
    salida = np.zeros((M, dv), dtype=np.float64)

    # Procesamiento por bloques de consultas.
    for inicio_q in range(0, M, bloque_consultas):

        fin_q = min(inicio_q + bloque_consultas, M)

        Q_bloque = Q[inicio_q:fin_q]

        cantidad_q = Q_bloque.shape[0]

        # Maximo acumulado del Softmax.
        m = np.full(
            (cantidad_q, 1),
            -np.inf
        )

        # Denominador acumulado.
        l = np.zeros(
            (cantidad_q, 1)
        )

        # Numerador acumulado.
        acumulador = np.zeros(
            (cantidad_q, dv)
        )

        # Procesamiento por bloques de claves y valores.
        for inicio_k in range(0, N, bloque_claves):

            fin_k = min(
                inicio_k + bloque_claves,
                N
            )

            K_bloque = K[inicio_k:fin_k]
            V_bloque = V[inicio_k:fin_k]

            # 1. Calcular puntuaciones del bloque.
            with np.errstate(over="ignore", invalid="ignore"):
                puntuaciones = (
                    Q_bloque @ K_bloque.T
                ) / escala

            if not np.all(np.isfinite(puntuaciones)):
                raise ValueError(
                    "Las puntuaciones de atencion exceden el rango numerico."
                )

            # 2. Maximo del bloque.
            m_bloque = np.max(
                puntuaciones,
                axis=1,
                keepdims=True
            )

            # 3. Nuevo maximo acumulado.
            m_nuevo = np.maximum(m, m_bloque)

            # 4. Factor de correccion.
            factor = np.exp(m - m_nuevo)

            # 5. Exponenciales normalizadas.
            probabilidades = np.exp(
                puntuaciones - m_nuevo
            )

            # 6. Actualizar denominador.
            l = (
                factor * l
                + np.sum(
                    probabilidades,
                    axis=1,
                    keepdims=True
                )
            )

            # 7. Actualizar numerador.
            acumulador = (
                factor * acumulador
                + probabilidades @ V_bloque
            )

            # 8. Actualizar maximo.
            m = m_nuevo

        # Resultado final del bloque de consultas.
        salida[inicio_q:fin_q] = acumulador / l

    if not np.all(np.isfinite(salida)):
        raise ValueError("El resultado de atencion excede el rango numerico.")

    return salida


# =====================================================
# 5. PRUEBA MANUAL
# =====================================================

if __name__ == "__main__":

    np.random.seed(42)

    cantidad = 100
    dimension = 32

    Q = np.random.rand(cantidad, dimension)
    K = np.random.rand(cantidad, dimension)
    V = np.random.rand(cantidad, dimension)

    print("=" * 55)
    print("BUSCADOR JUDICIAL - COMPONENTE C6")
    print("SISTEMA DE ATENCION")
    print("=" * 55)

    resultado_exacto = atencion_exacta(Q, K, V)

    resultado_bloques = atencion_bloques(
        Q,
        K,
        V,
        bloque_consultas=16,
        bloque_claves=16
    )

    diferencia = np.max(
        np.abs(resultado_exacto - resultado_bloques)
    )

    print("\nRESULTADOS")

    print("Dimension de entrada:", Q.shape)

    print("Dimension de salida:", resultado_exacto.shape)

    print("Atencion exacta calculada correctamente.")

    print("Atencion por bloques calculada correctamente.")

    print("Diferencia maxima:", diferencia)

    print(
        "Resultados equivalentes:",
        np.allclose(
            resultado_exacto,
            resultado_bloques,
            rtol=1e-10,
            atol=1e-12
        )
    )

    print("\nCOMPONENTE C6 EJECUTADO CORRECTAMENTE")
