
import pytest
import numpy as np

from C6_atencion.atencion import (
    validar_entradas,
    softmax,
    atencion_exacta,
    atencion_bloques
)


def generar_datos(m=100, d=32, dv=32, semilla=42):

    rng = np.random.default_rng(semilla)

    Q = rng.normal(size=(m, d))
    K = rng.normal(size=(m, d))
    V = rng.normal(size=(m, dv))

    return Q, K, V


def test_validacion_correcta():

    Q, K, V = generar_datos()

    q, k, v = validar_entradas(Q, K, V)

    assert q.shape == Q.shape
    assert k.shape == K.shape
    assert v.shape == V.shape


def test_matrices_no_son_dos_dimensiones():

    with pytest.raises(ValueError):

        validar_entradas(
            np.array([1, 2]),
            np.array([[1, 2]]),
            np.array([[1, 2]])
        )


def test_dimensiones_incompatibles():

    with pytest.raises(ValueError):

        validar_entradas(
            np.ones((5, 3)),
            np.ones((5, 4)),
            np.ones((5, 4))
        )


def test_matrices_vacias():

    with pytest.raises(ValueError):

        validar_entradas(
            np.empty((0, 3)),
            np.ones((5, 3)),
            np.ones((5, 3))
        )


def test_valores_no_finitos():

    Q, K, V = generar_datos()

    Q[0, 0] = np.nan

    with pytest.raises(ValueError):

        validar_entradas(Q, K, V)


def test_softmax_suma_uno():

    matriz = np.array([
        [1.0, 2.0, 3.0],
        [4.0, 5.0, 6.0]
    ])

    resultado = softmax(matriz)

    assert np.allclose(
        np.sum(resultado, axis=1),
        1.0
    )


def test_atencion_exacta():

    Q, K, V = generar_datos()

    resultado = atencion_exacta(Q, K, V)

    assert resultado.shape == V.shape
    assert np.all(np.isfinite(resultado))


def test_atencion_bloques():

    Q, K, V = generar_datos()

    resultado = atencion_bloques(
        Q, K, V,
        bloque_consultas=16,
        bloque_claves=16
    )

    assert resultado.shape == V.shape
    assert np.all(np.isfinite(resultado))


def test_equivalencia_algoritmos():

    Q, K, V = generar_datos()

    exacto = atencion_exacta(Q, K, V)

    bloques = atencion_bloques(
        Q, K, V,
        bloque_consultas=16,
        bloque_claves=16
    )

    assert np.allclose(
        exacto,
        bloques,
        rtol=1e-10,
        atol=1e-12
    )


def test_bloques_irregulares():

    Q, K, V = generar_datos(m=37, d=16)

    exacto = atencion_exacta(Q, K, V)

    bloques = atencion_bloques(
        Q, K, V,
        bloque_consultas=8,
        bloque_claves=11
    )

    assert np.allclose(exacto, bloques)


def test_bloque_invalido():

    Q, K, V = generar_datos()

    with pytest.raises(ValueError):

        atencion_bloques(
            Q, K, V,
            bloque_consultas=0
        )


def test_dimensiones_diferentes():

    Q, K, V = generar_datos(
        m=50,
        d=16,
        dv=24
    )

    exacto = atencion_exacta(Q, K, V)

    bloques = atencion_bloques(
        Q, K, V,
        bloque_consultas=10,
        bloque_claves=12
    )

    assert exacto.shape == (50, 24)

    assert np.allclose(exacto, bloques)


def test_reproducibilidad():

    Q1, K1, V1 = generar_datos(semilla=123)

    Q2, K2, V2 = generar_datos(semilla=123)

    resultado1 = atencion_exacta(Q1, K1, V1)

    resultado2 = atencion_exacta(Q2, K2, V2)

    assert np.array_equal(resultado1, resultado2)



def test_consultas_y_claves_pueden_tener_cantidades_distintas():
    rng = np.random.default_rng(7)
    Q = rng.normal(size=(7, 12))
    K = rng.normal(size=(13, 12))
    V = rng.normal(size=(13, 5))

    exacta = atencion_exacta(Q, K, V)
    bloques = atencion_bloques(
        Q, K, V, bloque_consultas=3, bloque_claves=4
    )
    assert exacta.shape == (7, 5)
    assert np.allclose(exacta, bloques)


def test_tamanos_de_bloque_deben_ser_enteros():
    Q, K, V = generar_datos()
    with pytest.raises(ValueError):
        atencion_bloques(Q, K, V, bloque_consultas=2.5)


def test_softmax_rechaza_valores_no_finitos():
    with pytest.raises(ValueError):
        softmax(np.array([[1.0, np.inf]]))



def test_rechaza_puntuaciones_fuera_de_rango_numerico():
    Q = np.array([[1e308]])
    K = np.array([[1e308]])
    V = np.array([[1.0]])

    with pytest.raises(ValueError):
        atencion_exacta(Q, K, V)

    with pytest.raises(ValueError):
        atencion_bloques(Q, K, V, bloque_consultas=1, bloque_claves=1)
