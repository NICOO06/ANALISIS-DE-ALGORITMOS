
"""
PROYECTO: BUSCADOR JUDICIAL
COMPONENTE C6: EXPERIMENTOS DE ATENCION

Compara:
1. Atencion exacta.
2. Atencion por bloques.

Mide:
- Tiempo de ejecucion.
- Mediana.
- Desviacion estandar.
- Memoria auxiliar teorica estimada.
- Equivalencia numerica.

Genera:
- Archivo CSV.
- Grafica de tiempos.
- Grafica de memoria.
"""

import csv
import time
import statistics
from pathlib import Path

import numpy as np
import matplotlib

matplotlib.use("Agg")

import matplotlib.pyplot as plt

from C6_atencion.atencion import (
    atencion_exacta,
    atencion_bloques
)


# =====================================================
# 1. CONFIGURACION
# =====================================================

BASE = Path(__file__).resolve().parent

CARPETA_RESULTADOS = BASE / "resultados"
CARPETA_GRAFICAS = BASE / "graficas"

CARPETA_RESULTADOS.mkdir(exist_ok=True)
CARPETA_GRAFICAS.mkdir(exist_ok=True)

TAMANOS = [128, 256, 512, 1024, 2048]

REPETICIONES = 5

DIMENSION = 32

BLOQUE_CONSULTAS = 64
BLOQUE_CLAVES = 64


# =====================================================
# 2. GENERAR DATOS
# =====================================================

def generar_datos(n, dimension=32):

    rng = np.random.default_rng(42 + n)

    Q = rng.normal(size=(n, dimension))
    K = rng.normal(size=(n, dimension))
    V = rng.normal(size=(n, dimension))

    return Q, K, V


# =====================================================
# 3. MEDIR TIEMPO
# =====================================================

def medir_tiempo(funcion, Q, K, V):

    inicio = time.perf_counter()

    resultado = funcion(Q, K, V)

    fin = time.perf_counter()

    tiempo = fin - inicio

    return tiempo, resultado


# =====================================================
# 4. ESTIMAR MEMORIA AUXILIAR
# =====================================================

def estimar_memoria_exacta(n, dimension=DIMENSION):
    """Estimacion de pico: scores + probabilidades + salida y vectores."""
    matriz = n * n * 8
    salida = n * dimension * 8
    vectores = 2 * n * 8
    return (2 * matriz + salida + vectores) / (1024 ** 2)


def estimar_memoria_bloques(
    n,
    dimension=DIMENSION,
    bloque_consultas=BLOQUE_CONSULTAS,
    bloque_claves=BLOQUE_CLAVES,
):
    """Estimacion de trabajo: salida, dos tiles y acumuladores."""
    bq = min(n, bloque_consultas)
    bk = min(n, bloque_claves)
    salida = n * dimension * 8
    tiles = 2 * bq * bk * 8
    acumuladores = (
        2 * bq * dimension * 8
        + 5 * bq * 8
    )
    return (salida + tiles + acumuladores) / (1024 ** 2)


# =====================================================
# 5. EXPERIMENTO PRINCIPAL
# =====================================================

def ejecutar_experimentos():

    resultados = []

    print("=" * 65)
    print("BUSCADOR JUDICIAL - EXPERIMENTOS C6")
    print("COMPARACION DE ALGORITMOS DE ATENCION")
    print("=" * 65)

    for n in TAMANOS:

        print(f"\nPROCESANDO TAMANO: {n} x {n}")

        Q, K, V = generar_datos(
            n,
            DIMENSION
        )

        tiempos_exactos = []
        tiempos_bloques = []

        # -----------------------------------------
        # Calentamiento de los algoritmos.
        # -----------------------------------------

        atencion_exacta(Q, K, V)

        atencion_bloques(
            Q,
            K,
            V,
            BLOQUE_CONSULTAS,
            BLOQUE_CLAVES
        )

        # -----------------------------------------
        # Repeticiones.
        # -----------------------------------------

        for repeticion in range(REPETICIONES):

            tiempo_exacto, resultado_exacto = medir_tiempo(
                atencion_exacta,
                Q, K, V
            )

            tiempo_bloques, resultado_bloques = medir_tiempo(
                lambda q, k, v: atencion_bloques(
                    q,
                    k,
                    v,
                    BLOQUE_CONSULTAS,
                    BLOQUE_CLAVES
                ),
                Q, K, V
            )

            tiempos_exactos.append(tiempo_exacto)
            tiempos_bloques.append(tiempo_bloques)

            equivalentes = np.allclose(
                resultado_exacto,
                resultado_bloques,
                rtol=1e-10,
                atol=1e-12
            )

            if not equivalentes:
                raise AssertionError(
                    f"Resultados diferentes para n={n}"
                )

            print(
                f"Repeticion {repeticion + 1}: "
                f"Exacta={tiempo_exacto:.6f}s | "
                f"Bloques={tiempo_bloques:.6f}s"
            )

        # -----------------------------------------
        # Estadisticas.
        # -----------------------------------------

        mediana_exacto = statistics.median(
            tiempos_exactos
        )

        mediana_bloques = statistics.median(
            tiempos_bloques
        )

        desviacion_exacto = statistics.pstdev(
            tiempos_exactos
        )

        desviacion_bloques = statistics.pstdev(
            tiempos_bloques
        )

        memoria_exacta = estimar_memoria_exacta(n, DIMENSION)

        memoria_bloques = estimar_memoria_bloques(
            n,
            DIMENSION,
            BLOQUE_CONSULTAS,
            BLOQUE_CLAVES,
        )

        resultado = {
            "tamano": n,
            "dimension": DIMENSION,
            "repeticiones": REPETICIONES,
            "mediana_exacto": mediana_exacto,
            "mediana_bloques": mediana_bloques,
            "desviacion_exacto": desviacion_exacto,
            "desviacion_bloques": desviacion_bloques,
            "memoria_exacta_mb": memoria_exacta,
            "memoria_bloques_mb": memoria_bloques,
            "equivalentes": equivalentes
        }

        resultados.append(resultado)

        print("\nESTADISTICAS")

        print(
            f"Mediana exacta: {mediana_exacto:.6f}s"
        )

        print(
            f"Mediana bloques: {mediana_bloques:.6f}s"
        )

        print(
            f"Desviacion exacta: {desviacion_exacto:.6f}s"
        )

        print(
            f"Desviacion bloques: {desviacion_bloques:.6f}s"
        )

        print(
            f"Memoria auxiliar estimada exacta: "
            f"{memoria_exacta:.4f} MB"
        )

        print(
            f"Memoria auxiliar estimada bloques: "
            f"{memoria_bloques:.4f} MB"
        )

        print("Resultados equivalentes:", equivalentes)

    return resultados


# =====================================================
# 6. GUARDAR RESULTADOS CSV
# =====================================================

def guardar_csv(resultados):

    archivo = CARPETA_RESULTADOS / "experimentos_atencion.csv"

    with open(
        archivo,
        "w",
        newline="",
        encoding="utf-8"
    ) as f:

        campos = list(resultados[0].keys())

        escritor = csv.DictWriter(
            f,
            fieldnames=campos
        )

        escritor.writeheader()

        escritor.writerows(resultados)

    print("\nCSV GENERADO:")
    print(archivo)


# =====================================================
# 7. GRAFICA DE TIEMPOS
# =====================================================

def generar_grafica_tiempos(resultados):

    tamanos = [
        r["tamano"] for r in resultados
    ]

    exactos = [
        r["mediana_exacto"] for r in resultados
    ]

    bloques = [
        r["mediana_bloques"] for r in resultados
    ]

    plt.figure(figsize=(10, 6))

    plt.plot(
        tamanos,
        exactos,
        marker="o",
        label="Atencion exacta"
    )

    plt.plot(
        tamanos,
        bloques,
        marker="s",
        label="Atencion por bloques"
    )

    plt.xscale("log", base=2)
    plt.yscale("log")

    plt.xlabel("Cantidad de elementos")

    plt.ylabel("Tiempo de ejecucion (segundos)")

    plt.title("Comparacion de tiempos - C6")

    plt.legend()

    plt.grid(True, which="both", linestyle="--")

    plt.tight_layout()

    archivo = CARPETA_GRAFICAS / "tiempos_atencion.png"

    plt.savefig(archivo, dpi=300)

    plt.close()

    print("\nGRAFICA DE TIEMPOS:")
    print(archivo)


# =====================================================
# 8. GRAFICA DE MEMORIA
# =====================================================

def generar_grafica_memoria(resultados):

    tamanos = [
        r["tamano"] for r in resultados
    ]

    exactos = [
        r["memoria_exacta_mb"] for r in resultados
    ]

    bloques = [
        r["memoria_bloques_mb"] for r in resultados
    ]

    plt.figure(figsize=(10, 6))

    plt.plot(
        tamanos,
        exactos,
        marker="o",
        label="Atencion exacta"
    )

    plt.plot(
        tamanos,
        bloques,
        marker="s",
        label="Atencion por bloques"
    )

    plt.xscale("log", base=2)
    plt.yscale("log")

    plt.xlabel("Cantidad de elementos")

    plt.ylabel("Memoria auxiliar estimada (MB)")

    plt.title("Comparacion de memoria auxiliar - C6")

    plt.legend()

    plt.grid(True, which="both", linestyle="--")

    plt.tight_layout()

    archivo = CARPETA_GRAFICAS / "memoria_atencion.png"

    plt.savefig(archivo, dpi=300)

    plt.close()

    print("\nGRAFICA DE MEMORIA:")
    print(archivo)


# =====================================================
# 9. EJECUCION PRINCIPAL
# =====================================================

if __name__ == "__main__":

    resultados = ejecutar_experimentos()

    guardar_csv(resultados)

    generar_grafica_tiempos(resultados)

    generar_grafica_memoria(resultados)

    print("\n" + "=" * 65)

    print("TODOS LOS EXPERIMENTOS FINALIZARON CORRECTAMENTE")

    print("=" * 65)
