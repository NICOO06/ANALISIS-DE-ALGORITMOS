import numpy as np
import pytest

from main import BuscadorJudicial, ejecutar_demostracion_c6


@pytest.fixture
def buscador():
    instancia = BuscadorJudicial()
    yield instancia
    instancia.cerrar()


def test_carga_corpus_e_indice(buscador):
    assert len(buscador.corpus) == 100
    assert len(buscador.indice) > 0
    assert len(buscador.por_id) == 100


def test_busqueda_por_termino(buscador):
    resultados = buscador.buscar("accidente")
    assert resultados
    assert all("accidente" in r["texto"].lower() for r in resultados)
    assert resultados[0]["puntuacion"] >= resultados[-1]["puntuacion"]


def test_busqueda_con_varios_terminos_es_and(buscador):
    resultados = buscador.buscar("accidente contrato")
    assert resultados
    assert all(
        "accidente" in r["texto"].lower()
        and "contrato" in r["texto"].lower()
        for r in resultados
    )


def test_sugerencia_de_termino_mal_escrito(buscador):
    sugerencias = buscador.sugerencias_para("accidnete")
    assert sugerencias[0] == ("accidente", 2)


def test_filtro_por_rango_de_fechas(buscador):
    resultados = buscador.buscar_por_rango("2024-01-01", "2024-12-31")
    assert resultados
    assert all("2024-01-01" <= r["fecha"] <= "2024-12-31" for r in resultados)


def test_busqueda_lexica_combinada_con_fechas(buscador):
    resultados = buscador.buscar(
        "accidente",
        "2024-01-01",
        "2024-12-31",
    )
    assert all("2024-01-01" <= r["fecha"] <= "2024-12-31" for r in resultados)


def test_rango_invertido_es_rechazado(buscador):
    with pytest.raises(ValueError):
        buscador.buscar_por_rango("2025-01-01", "2024-01-01")


def test_consulta_vacia_es_rechazada(buscador):
    with pytest.raises(ValueError):
        buscador.buscar("   ")


def test_mochila_selecciona_pasajes_dentro_del_presupuesto(buscador):
    buscador.buscar("accidente")
    resultado = buscador.recuperar_pasajes(presupuesto_tokens=100)
    assert resultado["tokens_utilizados"] <= 100 + 1e-9
    assert resultado["cantidad_pasajes"] > 0


def test_no_selecciona_pasajes_sin_busqueda(buscador):
    with pytest.raises(ValueError):
        buscador.recuperar_pasajes(presupuesto_tokens=100)


def test_estadisticas_integradas(buscador):
    estadisticas = buscador.estadisticas()
    assert estadisticas["expedientes"] == 100
    assert estadisticas["terminos_indexados"] > 0
    assert estadisticas["estadisticas_arbol"]["elementos_insertados"] == 100


def test_demostracion_c6_equivalente():
    resultado = ejecutar_demostracion_c6(cantidad=32, dimension=8)
    assert resultado["equivalentes"] is True
    assert resultado["forma"] == (32, 8)
    assert resultado["diferencia_maxima"] < 1e-9



def test_buscador_usa_el_vocabulario_del_corpus_indicado(tmp_path):
    import json

    ruta = tmp_path / "corpus_personalizado.json"
    corpus = [
        {
            "id": 1,
            "fecha": "2024-05-20",
            "tipo": "civil",
            "titulo": "Contrato",
            "texto": "contrato accidente judicial",
            "pasajes": [],
        },
        {
            "id": 2,
            "fecha": "2024-05-21",
            "tipo": "civil",
            "titulo": "Demanda",
            "texto": "demanda laboral sentencia",
            "pasajes": [],
        },
    ]
    ruta.write_text(json.dumps(corpus, ensure_ascii=False), encoding="utf-8")

    instancia = BuscadorJudicial(ruta)
    try:
        assert "laboral" in instancia.vocabulario
        assert "contrato" in instancia.vocabulario
        assert len(instancia.corpus) == 2
    finally:
        instancia.cerrar()


def test_mostrar_resultados_limita_salida_y_resume(capsys):
    from main import _mostrar_resultados

    resultados = [
        {
            "id": i,
            "fecha": "2024-01-01",
            "tipo": "civil",
            "titulo": f"Expediente {i}",
            "puntuacion": 10 - i,
            "texto": "Texto de prueba " * 30,
        }
        for i in range(1, 13)
    ]

    _mostrar_resultados(resultados, limite=10)
    salida = capsys.readouterr().out

    assert "Se encontraron 12 expediente(s)" in salida
    assert "Mostrando los 10 mas relevantes" in salida
    assert "Se omitieron 2 resultados adicionales" in salida
    assert "ID: 10" in salida
    assert "ID: 11" not in salida
    assert "ID: 12" not in salida


def test_busqueda_prioriza_coincidencias_en_metadatos(buscador):
    resultados = buscador.buscar("accidente")
    assert resultados
    assert resultados[0]["tipo"] == "accidente de transito"
