
"""
PRUEBAS DEL GENERADOR DE EXPEDIENTES
Proyecto: Buscador Judicial - Grupo 1
"""

from datos.generador import generar_corpus


def test_cantidad_expedientes():

    corpus = generar_corpus(100, semilla=42)

    assert len(corpus) == 100

    print("Cantidad de expedientes correcta.")


def test_identificadores_unicos():

    corpus = generar_corpus(100, semilla=42)

    identificadores = [
        expediente["id"] for expediente in corpus
    ]

    assert len(set(identificadores)) == 100

    print("Identificadores unicos.")


def test_pasajes_por_expediente():

    corpus = generar_corpus(100, semilla=42)

    for expediente in corpus:

        assert len(expediente["pasajes"]) == 3

    print("Todos los expedientes tienen 3 pasajes.")


def test_campos_expediente():

    corpus = generar_corpus(5, semilla=42)

    for expediente in corpus:

        assert "id" in expediente
        assert "fecha" in expediente
        assert "tipo" in expediente
        assert "titulo" in expediente
        assert "texto" in expediente
        assert "pasajes" in expediente

    print("Estructura de expedientes correcta.")


def test_reproducibilidad():

    corpus1 = generar_corpus(10, semilla=42)
    corpus2 = generar_corpus(10, semilla=42)

    assert corpus1 == corpus2

    print("Generacion reproducible correctamente.")


def test_cantidad_invalida():

    try:
        generar_corpus(0)
        assert False, "Debio producir un error."

    except ValueError:
        pass



def test_cantidad_debe_ser_entero():
    import pytest
    with pytest.raises(ValueError):
        generar_corpus(2.5)
