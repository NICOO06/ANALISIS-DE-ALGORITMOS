"""
BUSCADOR JUDICIAL - INTEGRACION DE LOS COMPONENTES C1 A C6.

C1: Merge Sort para ordenar los resultados.
C2: Arreglo dinamico e indice invertido para recuperar documentos.
C3: Levenshtein para sugerir terminos cuando hay errores de escritura.
C4: Mochila fraccionaria para seleccionar pasajes bajo un presupuesto.
C5: Arbol B+ para filtrar expedientes por fecha.
C6: Atencion exacta y por bloques como demostracion comparativa.

Ejecutar desde la raiz:
    python main.py
"""

from __future__ import annotations

import json
import re
from collections import Counter
from datetime import date
import tempfile
import time
from pathlib import Path
from typing import Any

import numpy as np

from C1_merge_sort.merge_sort import merge_sort
from C2_arreglo_dinamico.indice_invertido import (
    construir_indice_invertido,
    buscar_termino,
)
from C3_levenshtein.levenshtein import IndiceVocabulario, sugerir_terminos
from C3_levenshtein.vocabulario import cargar_vocabulario
from C4_mochila_fraccionaria.mochila_fraccionaria import (
    extraer_pasajes,
    seleccionar_pasajes,
)
from C5_arbol_b_mas.arbol_b_mas import ArbolBMas
from C6_atencion.atencion import atencion_exacta, atencion_bloques


RAIZ_PROYECTO = Path(__file__).resolve().parent
RUTA_CORPUS = RAIZ_PROYECTO / "datos" / "expedientes.json"
PATRON_PALABRAS = re.compile(r"[a-záéíóúüñ]+")
MAX_RESULTADOS_PANTALLA = 10
LONGITUD_PREVIA_TEXTO = 180


class BuscadorJudicial:
    """Coordina los seis componentes del proyecto."""

    def __init__(self, ruta_corpus: Path | str = RUTA_CORPUS):
        self.ruta_corpus = Path(ruta_corpus)
        self.corpus = self._cargar_corpus()
        self.por_id = {exp["id"]: exp for exp in self.corpus}

        # C1 + C2: el indice invertido se construye usando Merge Sort
        # y la estructura ArregloDinamico.
        self.indice = construir_indice_invertido(
            self.corpus,
            capacidad_inicial=4,
        )

        # C3: vocabulario derivado del corpus real.
        self.vocabulario = cargar_vocabulario(self.ruta_corpus)
        # El trie del vocabulario se construye una sola vez y se reutiliza en consultas.
        self.indice_vocabulario = IndiceVocabulario(self.vocabulario)

        # C5: el arbol utiliza un archivo temporal nuevo en cada ejecucion.
        # Asi no se reutiliza por accidente un disco de una ejecucion anterior.
        self._directorio_temporal = tempfile.TemporaryDirectory(
            prefix="buscador_judicial_"
        )
        ruta_disco = Path(self._directorio_temporal.name) / "indice_fechas.bin"
        self.arbol_fechas = ArbolBMas(
            orden=4,
            ruta_disco=str(ruta_disco),
        )
        for expediente in self.corpus:
            self.arbol_fechas.insertar(
                expediente["fecha"],
                expediente["id"],
            )

        self.ultimos_resultados: list[dict[str, Any]] = []

    def _cargar_corpus(self) -> list[dict[str, Any]]:
        if not self.ruta_corpus.exists():
            raise FileNotFoundError(
                f"No se encontro el corpus: {self.ruta_corpus}"
            )

        with self.ruta_corpus.open("r", encoding="utf-8") as archivo:
            corpus = json.load(archivo)

        if not isinstance(corpus, list):
            raise ValueError("El corpus debe ser una lista de expedientes.")

        for expediente in corpus:
            if not isinstance(expediente, dict):
                raise ValueError("Cada expediente debe ser un objeto.")
            for campo in ("id", "fecha", "texto", "pasajes"):
                if campo not in expediente:
                    raise ValueError(
                        f"Un expediente no contiene el campo obligatorio '{campo}'."
                    )
        return corpus

    @staticmethod
    def _tokenizar(texto: str) -> list[str]:
        return PATRON_PALABRAS.findall(texto.lower())

    def filtrar_por_fechas(
        self,
        fecha_inicio: str | None = None,
        fecha_fin: str | None = None,
    ) -> set[int] | None:
        """Devuelve IDs dentro del rango ISO inclusivo; None significa sin filtro."""
        if fecha_inicio is None and fecha_fin is None:
            return None
        if not fecha_inicio or not fecha_fin:
            raise ValueError(
                "Para filtrar por fecha debes indicar fecha inicial y final."
            )
        if fecha_inicio > fecha_fin:
            raise ValueError("La fecha inicial no puede superar la fecha final.")

        registros = self.arbol_fechas.buscar_rango(fecha_inicio, fecha_fin)
        return {
            identificador
            for registro in registros
            for identificador in registro["identificadores"]
        }

    def sugerencias_para(self, consulta: str, limite: int = 5):
        """Genera sugerencias para palabras de la consulta ausentes del indice."""
        sugerencias = []
        for termino in dict.fromkeys(self._tokenizar(consulta)):
            if termino not in self.indice:
                cercanas = sugerir_terminos(
                    termino,
                    self.vocabulario,
                    max_sugerencias=limite,
                    distancia_maxima=max(2, len(termino) // 3),
                    indice=self.indice_vocabulario,
                )
                sugerencias.extend(cercanas)

        # Quitar duplicados conservando la menor distancia.
        mejores: dict[str, int] = {}
        for termino, distancia in sugerencias:
            if termino not in mejores or distancia < mejores[termino]:
                mejores[termino] = distancia
        ordenadas = merge_sort((distancia, termino) for termino, distancia in mejores.items())
        return [(termino, distancia) for distancia, termino in ordenadas[:limite]]

    def buscar(
        self,
        consulta: str,
        fecha_inicio: str | None = None,
        fecha_fin: str | None = None,
    ) -> list[dict[str, Any]]:
        """
        Busca documentos que contengan todos los terminos de la consulta.
        Los resultados se ordenan por frecuencia de coincidencias y luego por ID.
        """
        if not isinstance(consulta, str) or not consulta.strip():
            raise ValueError("La consulta no puede estar vacia.")

        terminos = list(dict.fromkeys(self._tokenizar(consulta)))
        if not terminos:
            raise ValueError("La consulta no contiene palabras validas.")

        ids_por_fecha = self.filtrar_por_fechas(fecha_inicio, fecha_fin)

        publicaciones = [set(buscar_termino(self.indice, t)) for t in terminos]
        if any(not conjunto for conjunto in publicaciones):
            self.ultimos_resultados = []
            return []

        candidatos = set.intersection(*publicaciones)
        if ids_por_fecha is not None:
            candidatos.intersection_update(ids_por_fecha)

        resultados = []
        for identificador in candidatos:
            expediente = self.por_id.get(identificador)
            if expediente is None:
                continue

            # La frecuencia del cuerpo aporta relevancia; las coincidencias
            # en titulo y tipo reciben mayor peso por ser campos descriptivos.
            frecuencias_texto = Counter(self._tokenizar(expediente["texto"]))
            frecuencias_titulo = Counter(
                self._tokenizar(expediente.get("titulo", ""))
            )
            frecuencias_tipo = Counter(
                self._tokenizar(expediente.get("tipo", ""))
            )
            puntuacion = sum(
                frecuencias_texto[termino]
                + 5 * frecuencias_titulo[termino]
                + 3 * frecuencias_tipo[termino]
                for termino in terminos
            )
            resultados.append(((-puntuacion, identificador), expediente))

        # C1: Merge Sort ordena por mayor puntuacion y menor ID.
        ordenados = merge_sort(resultados)
        self.ultimos_resultados = [
            {
                "id": expediente["id"],
                "fecha": expediente["fecha"],
                "tipo": expediente.get("tipo", ""),
                "titulo": expediente.get("titulo", ""),
                "puntuacion": -clave[0],
                "texto": expediente["texto"],
            }
            for clave, expediente in ordenados
        ]
        return self.ultimos_resultados

    def buscar_por_rango(
        self,
        fecha_inicio: str,
        fecha_fin: str,
    ) -> list[dict[str, Any]]:
        """Consulta temporal usando directamente el arbol B+."""
        ids = self.filtrar_por_fechas(fecha_inicio, fecha_fin) or set()
        resultados = [
            self.por_id[i]
            for i in ids
            if i in self.por_id
        ]
        pares = [
            ((exp["fecha"], exp["id"]), exp)
            for exp in resultados
        ]
        return [
            {
                "id": exp["id"],
                "fecha": exp["fecha"],
                "tipo": exp.get("tipo", ""),
                "titulo": exp.get("titulo", ""),
                "texto": exp["texto"],
            }
            for _, exp in merge_sort(pares)
        ]

    def recuperar_pasajes(
        self,
        identificadores: list[int] | None = None,
        presupuesto_tokens: float = 1000,
    ) -> dict[str, Any]:
        """C4: selecciona pasajes de los expedientes indicados."""
        if identificadores is None:
            identificadores = [
                resultado["id"] for resultado in self.ultimos_resultados
            ]
        if not identificadores:
            raise ValueError(
                "Primero realiza una busqueda o indica IDs de expedientes."
            )

        expedientes = [
            self.por_id[i]
            for i in identificadores
            if i in self.por_id
        ]
        if not expedientes:
            raise ValueError("No hay expedientes validos para recuperar.")

        # C4: validar y aplanar los pasajes de los expedientes seleccionados.
        extraer_pasajes(expedientes)
        pasajes_con_origen = []
        for expediente in expedientes:
            for pasaje in expediente["pasajes"]:
                copia = pasaje.copy()
                copia["id_expediente"] = expediente["id"]
                copia["fecha_expediente"] = expediente["fecha"]
                copia["tipo_expediente"] = expediente.get("tipo", "")
                pasajes_con_origen.append(copia)

        return seleccionar_pasajes(
            pasajes_con_origen,
            presupuesto_tokens,
        )

    def estadisticas(self) -> dict[str, Any]:
        total_publicaciones = sum(
            len(arreglo) for arreglo in self.indice.values()
        )
        return {
            "expedientes": len(self.corpus),
            "terminos_indexados": len(self.indice),
            "publicaciones_indice": total_publicaciones,
            "registros_arbol_fechas": len(self.corpus),
            "estadisticas_arbol": self.arbol_fechas.obtener_estadisticas(),
        }

    def cerrar(self):
        """Libera el directorio temporal usado por el indice B+."""
        self._directorio_temporal.cleanup()


def ejecutar_demostracion_c6(
    cantidad: int = 128,
    dimension: int = 32,
    semilla: int = 42,
) -> dict[str, Any]:
    """
    C6: compara atencion exacta y por bloques con matrices reproducibles.
    Esta demostracion conserva la naturaleza numerica del componente:
    el corpus no contiene embeddings semanticos preentrenados.
    """
    if cantidad < 1 or dimension < 1:
        raise ValueError("La cantidad y la dimension deben ser positivas.")

    generador = np.random.default_rng(semilla)
    Q = generador.normal(size=(cantidad, dimension))
    K = generador.normal(size=(cantidad, dimension))
    V = generador.normal(size=(cantidad, dimension))

    inicio = time.perf_counter()
    exacta = atencion_exacta(Q, K, V)
    tiempo_exacto = time.perf_counter() - inicio

    inicio = time.perf_counter()
    bloques = atencion_bloques(Q, K, V)
    tiempo_bloques = time.perf_counter() - inicio

    return {
        "forma": exacta.shape,
        "tiempo_exacto": tiempo_exacto,
        "tiempo_bloques": tiempo_bloques,
        "equivalentes": bool(np.allclose(exacta, bloques, rtol=1e-9, atol=1e-10)),
        "diferencia_maxima": float(np.max(np.abs(exacta - bloques))),
    }


def _mostrar_resultados(
    resultados: list[dict[str, Any]],
    limite: int = MAX_RESULTADOS_PANTALLA,
) -> None:
    """Muestra solo los resultados principales para evitar saturar la consola."""
    if not resultados:
        print("\nNo se encontraron expedientes con todos los terminos.")
        return
    if isinstance(limite, bool) or not isinstance(limite, int) or limite < 1:
        raise ValueError("El limite de resultados debe ser un entero positivo.")

    cantidad_total = len(resultados)
    visibles = resultados[:limite]
    print(
        f"\nSe encontraron {cantidad_total} expediente(s). "
        f"Mostrando los {len(visibles)} mas relevantes:"
    )
    for posicion, resultado in enumerate(visibles, start=1):
        print("-" * 64)
        print(
            f"{posicion}. ID: {resultado['id']} | Fecha: {resultado['fecha']} | "
            f"Tipo: {resultado['tipo']}"
        )
        print(f"   Titulo: {resultado['titulo']}")
        print(f"   Relevancia: {resultado.get('puntuacion', 0)}")
        texto = " ".join(str(resultado.get("texto", "")).split())
        if len(texto) > LONGITUD_PREVIA_TEXTO:
            texto = texto[:LONGITUD_PREVIA_TEXTO].rstrip() + "..."
        print(f"   Texto: {texto}")

    if cantidad_total > len(visibles):
        restantes = cantidad_total - len(visibles)
        print(
            f"\nSe omitieron {restantes} resultados adicionales para no "
            "saturar la consola. Refina la busqueda agregando palabras "
            "o un rango de fechas."
        )


def _leer_fecha(mensaje: str) -> str | None:
    valor = input(mensaje).strip()
    if not valor:
        return None
    if not re.fullmatch(r"\d{4}-\d{2}-\d{2}", valor):
        raise ValueError("Formato de fecha invalido. Usa AAAA-MM-DD.")
    try:
        date.fromisoformat(valor)
    except ValueError as error:
        raise ValueError("La fecha ingresada no existe en el calendario.") from error
    return valor


def menu_principal() -> None:
    buscador = BuscadorJudicial()
    print("=" * 72)
    print("                 BUSCADOR JUDICIAL")
    print("=" * 72)
    print(f"Corpus cargado: {len(buscador.corpus)} expedientes.")
    print(f"Terminos indexados: {len(buscador.indice)}")

    try:
        while True:
            print("\nMENU PRINCIPAL")
            print("1. Buscar expedientes por palabras")
            print("2. Buscar expedientes por rango de fechas (Arbol B+)")
            print("3. Seleccionar pasajes relevantes (Mochila fraccionaria)")
            print("4. Ejecutar demostracion de atencion C6")
            print("5. Consultar estadisticas del buscador")
            print("0. Salir")

            opcion = input("\nSelecciona una opcion: ").strip()

            try:
                if opcion == "1":
                    consulta = input("Escribe los terminos de busqueda: ").strip()
                    inicio = _leer_fecha(
                        "Fecha inicial AAAA-MM-DD (Enter para omitir): "
                    )
                    fin = None
                    if inicio is not None:
                        fin = _leer_fecha("Fecha final AAAA-MM-DD: ")
                    resultados = buscador.buscar(consulta, inicio, fin)
                    _mostrar_resultados(resultados)

                    if not resultados:
                        sugerencias = buscador.sugerencias_para(consulta)
                        if sugerencias:
                            print("\nPosibles correcciones:")
                            for termino, distancia in sugerencias:
                                print(f"  {termino} (distancia {distancia})")

                elif opcion == "2":
                    inicio = _leer_fecha("Fecha inicial AAAA-MM-DD: ")
                    fin = _leer_fecha("Fecha final AAAA-MM-DD: ")
                    if not inicio or not fin:
                        raise ValueError("Debes indicar ambas fechas.")
                    resultados = buscador.buscar_por_rango(inicio, fin)
                    _mostrar_resultados([
                        {**r, "puntuacion": 0} for r in resultados
                    ])

                elif opcion == "3":
                    if not buscador.ultimos_resultados:
                        print("Primero realiza una busqueda en la opcion 1.")
                        continue
                    valor = input(
                        "Presupuesto maximo de tokens [1000]: "
                    ).strip()
                    presupuesto = float(valor) if valor else 1000
                    seleccion = buscador.recuperar_pasajes(
                        presupuesto_tokens=presupuesto
                    )
                    print("\nRESULTADO DE SELECCION DE PASAJES")
                    print(f"Presupuesto: {seleccion['presupuesto']}")
                    print(f"Tokens utilizados: {seleccion['tokens_utilizados']:.2f}")
                    print(f"Relevancia total: {seleccion['relevancia_total']:.2f}")
                    print(f"Pasajes seleccionados: {seleccion['cantidad_pasajes']}")
                    for pasaje in seleccion["seleccionados"]:
                        print("-" * 72)
                        print(
                            f"Expediente: {pasaje['id_expediente']} | "
                            f"Pasaje: {pasaje['id_pasaje']} | "
                            f"Seccion: {pasaje.get('seccion', '')}"
                        )
                        print(
                            f"Fraccion: {pasaje['fraccion']:.2%} | "
                            f"Tokens: {pasaje['tokens_asignados']:.2f} | "
                            f"Relevancia: {pasaje['relevancia_obtenida']:.2f}"
                        )
                        print(pasaje["texto_seleccionado"][:300])

                elif opcion == "4":
                    resultado = ejecutar_demostracion_c6()
                    print("\nDEMOSTRACION C6 - ATENCION")
                    print(f"Forma de salida: {resultado['forma']}")
                    print(f"Tiempo exacto: {resultado['tiempo_exacto']:.6f} s")
                    print(f"Tiempo por bloques: {resultado['tiempo_bloques']:.6f} s")
                    print(f"Diferencia maxima: {resultado['diferencia_maxima']:.3e}")
                    print(f"Resultados equivalentes: {resultado['equivalentes']}")

                elif opcion == "5":
                    estadisticas = buscador.estadisticas()
                    print("\nESTADISTICAS DEL BUSCADOR")
                    print(f"Expedientes: {estadisticas['expedientes']}")
                    print(f"Terminos indexados: {estadisticas['terminos_indexados']}")
                    print(f"Publicaciones del indice: {estadisticas['publicaciones_indice']}")
                    print("\nESTADISTICAS DEL ARBOL B+")
                    for nombre, valor in estadisticas["estadisticas_arbol"].items():
                        print(f"{nombre}: {valor}")

                elif opcion == "0":
                    print("\nCerrando el buscador judicial.")
                    break

                else:
                    print("Opcion no valida. Intenta nuevamente.")

            except (ValueError, FileNotFoundError) as error:
                print(f"\nNo se pudo completar la operacion: {error}")

    except (KeyboardInterrupt, EOFError):
        print("\nEjecucion interrumpida por el usuario.")
    finally:
        buscador.cerrar()


if __name__ == "__main__":
    menu_principal()
