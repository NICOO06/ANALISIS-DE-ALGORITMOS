
"""
PROYECTO: BUSCADOR JUDICIAL
COMPONENTE C5: ARBOL B+
ALGORITMO: INDEXACION Y BUSQUEDA EN DISCO

Implementa un arbol B+ con:
- Nodos internos y hojas.
- Insercion y division de nodos.
- Busqueda por fecha.
- Busqueda por rangos.
- Hojas enlazadas.
- Almacenamiento mediante disco simulado.
- Estadisticas de entrada y salida.
"""

from bisect import bisect_left, bisect_right
from datetime import date
import re
from .disco_simulado import DiscoSimulado


class ArbolBMas:

    # -----------------------------------------
    # 1. CONSTRUCTOR
    # -----------------------------------------

    def __init__(
        self,
        orden=4,
        ruta_disco="C5_arbol_b_mas/arbol_b_mas.bin",
        tamano_bloque=4096,
        memoria_bytes=None
    ):

        if (
            isinstance(orden, bool)
            or not isinstance(orden, int)
            or orden < 3
        ):
            raise ValueError(
                "El orden del arbol debe ser un entero minimo de 3."
            )

        self.orden = orden

        # Maximo numero de claves por nodo.
        self.max_claves = orden - 1

        if memoria_bytes is not None:
            if (isinstance(memoria_bytes, bool) or not isinstance(memoria_bytes, int)
                    or memoria_bytes < tamano_bloque):
                raise ValueError("M debe permitir almacenar al menos un bloque B.")
            capacidad_bloques = memoria_bytes // tamano_bloque
        else:
            capacidad_bloques = None

        self.memoria_bytes = memoria_bytes
        self.disco = DiscoSimulado(
            ruta_disco,
            tamano_bloque,
            capacidad_memoria_bloques=capacidad_bloques
        )

        # Crear raiz inicial si el disco esta vacio.
        if self.disco.cantidad_bloques() == 0:

            raiz = {
                "tipo": "hoja",
                "claves": [],
                "valores": [],
                "siguiente": None
            }

            self.raiz = self.disco.reservar_bloque(raiz)

        else:
            raise ValueError(
                "El archivo de disco ya contiene bloques. "
                "Utiliza un archivo nuevo para crear otro arbol."
            )

        self.elementos = 0

    # -----------------------------------------
    # 2. LEER Y ESCRIBIR NODOS
    # -----------------------------------------

    def _leer_nodo(self, indice):

        return self.disco.leer_bloque(indice)

    def _escribir_nodo(self, indice, nodo):

        self.disco.escribir_bloque(
            indice,
            nodo
        )

    def _crear_nodo(self, nodo):

        return self.disco.reservar_bloque(nodo)

    @staticmethod
    def _validar_fecha(fecha):
        """Exige fechas reales en formato ISO AAAA-MM-DD."""
        if not isinstance(fecha, str):
            raise ValueError("La fecha debe ser una cadena AAAA-MM-DD.")

        fecha = fecha.strip()
        if not re.fullmatch(r"\d{4}-\d{2}-\d{2}", fecha):
            raise ValueError("La fecha debe tener formato AAAA-MM-DD.")

        try:
            date.fromisoformat(fecha)
        except ValueError as error:
            raise ValueError(
                "La fecha no es una fecha de calendario valida."
            ) from error

        return fecha

    # -----------------------------------------
    # 3. INSERTAR UNA FECHA Y SU IDENTIFICADOR
    # -----------------------------------------

    def insertar(self, fecha, identificador):
        fecha = self._validar_fecha(fecha)

        if (
            isinstance(identificador, bool)
            or not isinstance(identificador, (str, int))
            or (isinstance(identificador, str) and not identificador.strip())
        ):
            raise ValueError(
                "El identificador debe ser texto no vacio o entero."
            )

        resultado, insertado = self._insertar_recursivo(
            self.raiz,
            fecha,
            identificador
        )

        if resultado is not None:
            clave_promovida, nuevo_hijo = resultado
            nueva_raiz = {
                "tipo": "interno",
                "claves": [clave_promovida],
                "hijos": [self.raiz, nuevo_hijo]
            }
            self.raiz = self._crear_nodo(nueva_raiz)

        if insertado:
            self.elementos += 1

    # -----------------------------------------
    # 4. INSERCION RECURSIVA
    # -----------------------------------------

    def _insertar_recursivo(
        self,
        indice,
        fecha,
        identificador
    ):
        nodo = self._leer_nodo(indice)

        # CASO A: EL NODO ES UNA HOJA.
        if nodo["tipo"] == "hoja":
            posicion = bisect_left(nodo["claves"], fecha)

            # Una pareja (fecha, identificador) no se duplica.
            if (
                posicion < len(nodo["claves"])
                and nodo["claves"][posicion] == fecha
            ):
                if identificador in nodo["valores"][posicion]:
                    return None, False

                nodo["valores"][posicion].append(identificador)
                self._escribir_nodo(indice, nodo)
                return None, True

            nodo["claves"].insert(posicion, fecha)
            nodo["valores"].insert(posicion, [identificador])

            if len(nodo["claves"]) <= self.max_claves:
                self._escribir_nodo(indice, nodo)
                return None, True

            # DIVISION DE HOJA.
            punto_division = (len(nodo["claves"]) + 1) // 2
            nuevas_claves = nodo["claves"][punto_division:]
            nuevos_valores = nodo["valores"][punto_division:]

            nueva_hoja = {
                "tipo": "hoja",
                "claves": nuevas_claves,
                "valores": nuevos_valores,
                "siguiente": nodo["siguiente"]
            }
            nuevo_indice = self._crear_nodo(nueva_hoja)

            nodo["claves"] = nodo["claves"][:punto_division]
            nodo["valores"] = nodo["valores"][:punto_division]
            nodo["siguiente"] = nuevo_indice
            self._escribir_nodo(indice, nodo)

            return (nuevas_claves[0], nuevo_indice), True

        # CASO B: EL NODO ES INTERNO.
        posicion = bisect_right(nodo["claves"], fecha)
        resultado, insertado = self._insertar_recursivo(
            nodo["hijos"][posicion],
            fecha,
            identificador
        )

        if not insertado:
            return None, False
        if resultado is None:
            return None, True

        clave_promovida, nuevo_hijo = resultado
        nodo["claves"].insert(posicion, clave_promovida)
        nodo["hijos"].insert(posicion + 1, nuevo_hijo)

        if len(nodo["claves"]) <= self.max_claves:
            self._escribir_nodo(indice, nodo)
            return None, True

        # DIVISION DE NODO INTERNO.
        medio = len(nodo["claves"]) // 2
        clave_subida = nodo["claves"][medio]
        nodo_derecho = {
            "tipo": "interno",
            "claves": nodo["claves"][medio + 1:],
            "hijos": nodo["hijos"][medio + 1:]
        }
        nodo["claves"] = nodo["claves"][:medio]
        nodo["hijos"] = nodo["hijos"][:medio + 1]

        nuevo_indice = self._crear_nodo(nodo_derecho)
        self._escribir_nodo(indice, nodo)

        return (clave_subida, nuevo_indice), True

    def _buscar_hoja(self, fecha):

        indice = self.raiz

        while True:

            nodo = self._leer_nodo(indice)

            if nodo["tipo"] == "hoja":

                return indice, nodo

            posicion = bisect_right(
                nodo["claves"],
                fecha
            )

            indice = nodo["hijos"][posicion]

    # -----------------------------------------
    # 6. BUSQUEDA PUNTUAL
    # -----------------------------------------

    def buscar(self, fecha):
        fecha = self._validar_fecha(fecha)

        _, hoja = self._buscar_hoja(fecha)
        posicion = bisect_left(hoja["claves"], fecha)

        if (
            posicion < len(hoja["claves"])
            and hoja["claves"][posicion] == fecha
        ):

            return hoja["valores"][posicion].copy()

        return []

    # -----------------------------------------
    # 7. BUSQUEDA POR RANGO
    # -----------------------------------------

    def buscar_rango(self, fecha_inicio, fecha_fin):
        fecha_inicio = self._validar_fecha(fecha_inicio)
        fecha_fin = self._validar_fecha(fecha_fin)

        if fecha_inicio > fecha_fin:
            raise ValueError(
                "La fecha inicial no puede superar "
                "la fecha final."
            )

        indice, hoja = self._buscar_hoja(
            fecha_inicio
        )

        resultados = []

        while True:

            for posicion, fecha in enumerate(hoja["claves"]):

                if fecha > fecha_fin:
                    return resultados

                if fecha >= fecha_inicio:

                    resultados.append({
                        "fecha": fecha,
                        "identificadores": (
                            hoja["valores"][posicion].copy()
                        )
                    })

            if hoja["siguiente"] is None:
                break

            indice = hoja["siguiente"]

            hoja = self._leer_nodo(
                indice
            )

        return resultados

    # -----------------------------------------
    # 8. OBTENER TODAS LAS CLAVES
    # -----------------------------------------

    def obtener_todos(self):

        indice, hoja = self._buscar_hoja("")

        resultados = []

        while True:

            for posicion, fecha in enumerate(hoja["claves"]):

                resultados.append({
                    "fecha": fecha,
                    "identificadores": (
                        hoja["valores"][posicion].copy()
                    )
                })

            if hoja["siguiente"] is None:
                break

            indice = hoja["siguiente"]

            hoja = self._leer_nodo(
                indice
            )

        return resultados

    # -----------------------------------------
    # 9. ESTADISTICAS DEL ARBOL
    # -----------------------------------------

    def obtener_estadisticas(self):

        estadisticas_disco = (
            self.disco.obtener_estadisticas()
        )

        return {
            "elementos_insertados": self.elementos,
            "orden": self.orden,
            "maximo_claves_por_nodo": self.max_claves,
            "memoria_bytes_M": self.memoria_bytes,
            "bloques_buffer_M_sobre_B": self.disco.capacidad_memoria_bloques,
            "tamano_bloque_B": self.disco.tamano_bloque,
            "bloques_ocupados": (
                estadisticas_disco["bloques_totales"]
            ),
            "lecturas": estadisticas_disco["lecturas"],
            "escrituras": estadisticas_disco["escrituras"],
            "total_operaciones": (
                estadisticas_disco["total_operaciones"]
            ),
            "bytes_leidos": estadisticas_disco["bytes_leidos"],
            "bytes_escritos": estadisticas_disco["bytes_escritos"]
        }

    # -----------------------------------------
    # 10. MOSTRAR ESTADISTICAS
    # -----------------------------------------

    def mostrar_estadisticas(self):

        print("\nESTADISTICAS DEL ARBOL B+")
        print("--------------------------------")

        for nombre, valor in self.obtener_estadisticas().items():

            print(f"{nombre}: {valor}")

    # -----------------------------------------
    # 11. MOSTRAR REGISTROS
    # -----------------------------------------

    def mostrar_registros(self):

        registros = self.obtener_todos()

        print("\nREGISTROS DEL ARBOL B+")
        print("--------------------------------")

        for registro in registros:

            print(
                registro["fecha"],
                "->",
                registro["identificadores"]
            )


# -----------------------------------------
# 12. PRUEBA MANUAL
# -----------------------------------------

if __name__ == "__main__":

    arbol = ArbolBMas(
        orden=4,
        ruta_disco="C5_arbol_b_mas/prueba_arbol.bin"
    )

    expedientes = [
        ("2024-05-20", 1),
        ("2023-02-15", 2),
        ("2024-01-10", 3),
        ("2022-08-30", 4),
        ("2025-03-12", 5),
        ("2024-05-20", 6),
        ("2023-11-25", 7),
        ("2025-07-18", 8),
        ("2022-04-05", 9),
        ("2024-09-14", 10)
    ]

    print("BUSCADOR JUDICIAL - ARBOL B+")
    print("================================")

    for fecha, identificador in expedientes:

        arbol.insertar(
            fecha,
            identificador
        )

    arbol.mostrar_registros()

    print("\nBUSQUEDA PUNTUAL")

    print(
        "2024-05-20:",
        arbol.buscar("2024-05-20")
    )

    print("\nBUSQUEDA POR RANGO")

    resultados = arbol.buscar_rango(
        "2023-01-01",
        "2024-12-31"
    )

    for resultado in resultados:
        print(resultado)

    arbol.mostrar_estadisticas()
