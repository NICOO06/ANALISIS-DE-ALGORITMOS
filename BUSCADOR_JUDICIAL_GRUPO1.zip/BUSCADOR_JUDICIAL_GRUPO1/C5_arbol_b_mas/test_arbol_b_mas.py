
"""
PROYECTO: BUSCADOR JUDICIAL
COMPONENTE C5: ARBOL B+
PRUEBAS AUTOMATIZADAS CON PYTEST
"""

import pytest

from C5_arbol_b_mas.arbol_b_mas import ArbolBMas
from C5_arbol_b_mas.disco_simulado import DiscoSimulado


@pytest.fixture
def arbol(tmp_path):

    ruta = tmp_path / "arbol_test.bin"

    return ArbolBMas(
        orden=4,
        ruta_disco=str(ruta)
    )


def test_insercion_basica(arbol):

    arbol.insertar("2024-05-20", 1)

    assert arbol.buscar("2024-05-20") == [1]


def test_busqueda_inexistente(arbol):

    arbol.insertar("2024-05-20", 1)

    assert arbol.buscar("2025-01-01") == []


def test_fechas_duplicadas(arbol):

    arbol.insertar("2024-05-20", 1)
    arbol.insertar("2024-05-20", 2)

    assert arbol.buscar("2024-05-20") == [1, 2]


def test_identificador_duplicado(arbol):

    arbol.insertar("2024-05-20", 1)
    arbol.insertar("2024-05-20", 1)

    assert arbol.buscar("2024-05-20") == [1]
    assert arbol.obtener_estadisticas()["elementos_insertados"] == 1


def test_ordenamiento(arbol):

    fechas = [
        "2025-01-10",
        "2022-03-15",
        "2024-06-20",
        "2023-08-12"
    ]

    for i, fecha in enumerate(fechas):

        arbol.insertar(fecha, i)

    resultado = arbol.obtener_todos()

    fechas_obtenidas = [
        registro["fecha"]
        for registro in resultado
    ]

    assert fechas_obtenidas == sorted(fechas)


def test_division_hojas(arbol):

    for i in range(20):

        fecha = f"2024-01-{i + 1:02d}"

        arbol.insertar(fecha, i)

    assert len(arbol.obtener_todos()) == 20

    assert arbol.buscar("2024-01-15") == [14]


def test_division_nodos_internos(arbol):

    for i in range(100):

        fecha = f"2024-{(i // 28) + 1:02d}-{(i % 28) + 1:02d}"

        arbol.insertar(fecha, i)

    resultado = arbol.obtener_todos()

    assert len(resultado) == 100


def test_busqueda_por_rango(arbol):

    fechas = [
        "2022-01-10",
        "2023-05-20",
        "2024-02-15",
        "2024-08-10",
        "2025-03-12"
    ]

    for i, fecha in enumerate(fechas):

        arbol.insertar(fecha, i)

    resultado = arbol.buscar_rango(
        "2023-01-01",
        "2024-12-31"
    )

    fechas_resultado = [
        registro["fecha"]
        for registro in resultado
    ]

    assert fechas_resultado == [
        "2023-05-20",
        "2024-02-15",
        "2024-08-10"
    ]


def test_rango_sin_resultados(arbol):

    arbol.insertar("2024-05-20", 1)

    resultado = arbol.buscar_rango(
        "2025-01-01",
        "2025-12-31"
    )

    assert resultado == []


def test_rango_invertido(arbol):

    with pytest.raises(ValueError):

        arbol.buscar_rango(
            "2025-01-01",
            "2024-01-01"
        )


def test_consulta_vacia(arbol):

    with pytest.raises(ValueError):

        arbol.buscar("")


def test_fecha_invalida(arbol):

    with pytest.raises(ValueError):

        arbol.insertar("", 1)


def test_orden_invalido():

    with pytest.raises(ValueError):

        ArbolBMas(
            orden=2
        )


def test_estadisticas(arbol):

    arbol.insertar("2024-05-20", 1)

    arbol.buscar("2024-05-20")

    estadisticas = arbol.obtener_estadisticas()

    assert estadisticas["elementos_insertados"] == 1

    assert estadisticas["lecturas"] > 0

    assert estadisticas["escrituras"] > 0

    assert estadisticas["bloques_ocupados"] > 0


def test_multiples_inserciones_y_busquedas(arbol):

    for i in range(200):

        fecha = f"2024-{(i // 28) + 1:02d}-{(i % 28) + 1:02d}"

        arbol.insertar(fecha, i)

    assert len(arbol.obtener_todos()) == 200

    for i in range(200):

        fecha = f"2024-{(i // 28) + 1:02d}-{(i % 28) + 1:02d}"

        assert arbol.buscar(fecha) == [i]



def test_fecha_calendario_invalida(arbol):
    with pytest.raises(ValueError):
        arbol.insertar("2024-02-30", 1)


def test_fecha_formato_invalido(arbol):
    with pytest.raises(ValueError):
        arbol.buscar("20/05/2024")


def test_orden_debe_ser_entero():
    with pytest.raises(ValueError):
        ArbolBMas(orden=3.5)


def test_busqueda_rango_valida_fechas_reales(arbol):
    with pytest.raises(ValueError):
        arbol.buscar_rango("2024-02-30", "2024-03-01")



def test_identificador_repetido_en_otra_fecha_es_un_registro_distinto(arbol):
    arbol.insertar("2024-05-20", 1)
    arbol.insertar("2024-05-21", 1)
    assert arbol.obtener_estadisticas()["elementos_insertados"] == 2


def test_fecha_de_busqueda_invalida(arbol):
    with pytest.raises(ValueError):
        arbol.buscar("2024-13-01")


def test_fecha_de_rango_debe_ser_iso(arbol):
    with pytest.raises(ValueError):
        arbol.buscar_rango("2024/01/01", "2024-12-31")



def test_tamano_bloque_debe_ser_entero(tmp_path):
    with pytest.raises(ValueError):
        DiscoSimulado(str(tmp_path / "disco.bin"), tamano_bloque=64.5)


def test_memoria_limitada_por_M_sobre_B(tmp_path):
    arbol = ArbolBMas(
        orden=4, ruta_disco=str(tmp_path / "arbol_M.bin"),
        tamano_bloque=1024, memoria_bytes=2048
    )
    assert arbol.disco.capacidad_memoria_bloques == 2
    for i in range(30):
        arbol.insertar(f"2024-01-{i + 1:02d}", i)
    assert arbol.buscar("2024-01-15") == [14]
    assert arbol.obtener_estadisticas()["bloques_buffer_M_sobre_B"] == 2


def test_cache_cuenta_solo_fallos_de_lectura_y_vuelcos(tmp_path):
    disco = DiscoSimulado(str(tmp_path / "cache.bin"), 256, capacidad_memoria_bloques=1)
    indice = disco.reservar_bloque({"valor": 1})
    disco.reiniciar_estadisticas()
    assert disco.leer_bloque(indice) == {"valor": 1}
    assert disco.leer_bloque(indice) == {"valor": 1}
    assert disco.obtener_estadisticas()["lecturas"] == 1
    disco.escribir_bloque(indice, {"valor": 2})
    disco.vaciar_cache()
    assert disco.leer_bloque(indice) == {"valor": 2}
