
"""
PROYECTO: BUSCADOR JUDICIAL
COMPONENTE C5: ARBOL B+
MODULO: DISCO SIMULADO

Simula almacenamiento en disco mediante bloques
de tamaño fijo en un archivo binario.

Todas las lecturas y escrituras se contabilizan.
"""

import json
import os
import struct
from collections import OrderedDict
from copy import deepcopy


class DiscoSimulado:

    def __init__(self, ruta_archivo, tamano_bloque=4096, capacidad_memoria_bloques=None):

        if (
            isinstance(tamano_bloque, bool)
            or not isinstance(tamano_bloque, int)
            or tamano_bloque <= 4
        ):
            raise ValueError(
                "El tamaño del bloque debe ser un entero mayor a 4 bytes."
            )

        self.ruta_archivo = ruta_archivo
        self.tamano_bloque = tamano_bloque
        if capacidad_memoria_bloques is not None and (
            isinstance(capacidad_memoria_bloques, bool)
            or not isinstance(capacidad_memoria_bloques, int)
            or capacidad_memoria_bloques < 1
        ):
            raise ValueError("La memoria debe permitir almacenar al menos un bloque.")
        self.capacidad_memoria_bloques = capacidad_memoria_bloques
        self._cache = OrderedDict()

        # Estadísticas de entrada y salida físicas del disco simulado.
        self.lecturas = 0
        self.escrituras = 0
        self.bytes_leidos = 0
        self.bytes_escritos = 0

        # Crear directorio si no existe.
        directorio = os.path.dirname(ruta_archivo)

        if directorio:
            os.makedirs(directorio, exist_ok=True)

        # Crear archivo binario si todavía no existe.
        if not os.path.exists(ruta_archivo):
            with open(ruta_archivo, "wb"):
                pass

    # -----------------------------------------
    # 1. CANTIDAD DE BLOQUES
    # -----------------------------------------

    def cantidad_bloques(self):

        tamano_archivo = os.path.getsize(
            self.ruta_archivo
        )

        if tamano_archivo % self.tamano_bloque != 0:
            raise IOError(
                "El archivo tiene un tamaño incompatible."
            )

        return tamano_archivo // self.tamano_bloque

    # -----------------------------------------
    # 2. RESERVAR UN NUEVO BLOQUE
    # -----------------------------------------

    def reservar_bloque(self, datos):

        indice = self.cantidad_bloques()

        contenido = self._serializar(datos)

        with open(self.ruta_archivo, "ab") as archivo:

            archivo.write(contenido)

        self.escrituras += 1
        self.bytes_escritos += self.tamano_bloque
        if self.capacidad_memoria_bloques is not None:
            self._cache[indice] = {"datos": deepcopy(datos), "sucio": False}
            self._cache.move_to_end(indice)
            self._controlar_capacidad_cache()

        return indice

    # -----------------------------------------
    # 3. ESCRIBIR UN BLOQUE EXISTENTE
    # -----------------------------------------

    def escribir_bloque(self, indice, datos):

        if indice < 0 or indice >= self.cantidad_bloques():
            raise IndexError("El bloque solicitado no existe.")

        if self.capacidad_memoria_bloques is None:
            self._escribir_fisico(indice, datos)
            return

        self._cache[indice] = {"datos": deepcopy(datos), "sucio": True}
        self._cache.move_to_end(indice)
        self._controlar_capacidad_cache()

    def _escribir_fisico(self, indice, datos):
        contenido = self._serializar(datos)
        posicion = indice * self.tamano_bloque
        with open(self.ruta_archivo, "r+b") as archivo:
            archivo.seek(posicion)
            archivo.write(contenido)
        self.escrituras += 1
        self.bytes_escritos += self.tamano_bloque

    def _controlar_capacidad_cache(self):
        if self.capacidad_memoria_bloques is None:
            return
        while len(self._cache) > self.capacidad_memoria_bloques:
            indice, entrada = self._cache.popitem(last=False)
            if entrada["sucio"]:
                self._escribir_fisico(indice, entrada["datos"])

    def vaciar_cache(self, limpiar=True):
        """Escribe bloques sucios; opcionalmente libera todos los marcos."""
        for indice, entrada in list(self._cache.items()):
            if entrada["sucio"]:
                self._escribir_fisico(indice, entrada["datos"])
                entrada["sucio"] = False
        if limpiar:
            self._cache.clear()

    # -----------------------------------------
    # 4. LEER UN BLOQUE
    # -----------------------------------------

    def leer_bloque(self, indice):

        if indice < 0 or indice >= self.cantidad_bloques():
            raise IndexError("El bloque solicitado no existe.")

        if self.capacidad_memoria_bloques is not None and indice in self._cache:
            entrada = self._cache[indice]
            self._cache.move_to_end(indice)
            return deepcopy(entrada["datos"])

        posicion = indice * self.tamano_bloque
        with open(self.ruta_archivo, "rb") as archivo:
            archivo.seek(posicion)
            contenido = archivo.read(self.tamano_bloque)

        if len(contenido) != self.tamano_bloque:
            raise IOError("No se pudo leer el bloque completo.")

        self.lecturas += 1
        self.bytes_leidos += self.tamano_bloque

        longitud = struct.unpack(">I", contenido[:4])[0]
        if longitud > self.tamano_bloque - 4:
            raise IOError("El contenido del bloque está corrupto.")

        datos = json.loads(contenido[4:4 + longitud].decode("utf-8"))

        if self.capacidad_memoria_bloques is not None:
            self._cache[indice] = {"datos": deepcopy(datos), "sucio": False}
            self._cache.move_to_end(indice)
            self._controlar_capacidad_cache()

        return datos

    # -----------------------------------------
    # 5. SERIALIZAR INFORMACION
    # -----------------------------------------

    def _serializar(self, datos):

        contenido = json.dumps(
            datos,
            ensure_ascii=False
        ).encode("utf-8")

        espacio_disponible = self.tamano_bloque - 4

        if len(contenido) > espacio_disponible:

            raise ValueError(
                "Los datos superan la capacidad del bloque."
            )

        longitud = struct.pack(
            ">I",
            len(contenido)
        )

        contenido_completo = (
            longitud
            + contenido
        )

        # Completar hasta alcanzar el tamaño fijo.
        relleno = (
            self.tamano_bloque
            - len(contenido_completo)
        )

        return contenido_completo + (b"\x00" * relleno)

    # -----------------------------------------
    # 6. ESTADISTICAS DE ENTRADA Y SALIDA
    # -----------------------------------------

    def obtener_estadisticas(self):

        self.vaciar_cache(limpiar=False)
        return {
            "lecturas": self.lecturas,
            "escrituras": self.escrituras,
            "total_operaciones": (
                self.lecturas + self.escrituras
            ),
            "bytes_leidos": self.bytes_leidos,
            "bytes_escritos": self.bytes_escritos,
            "bloques_totales": self.cantidad_bloques(),
            "tamano_bloque": self.tamano_bloque,
            "capacidad_memoria_bloques": self.capacidad_memoria_bloques,
            "bloques_en_cache": len(self._cache)
        }

    # -----------------------------------------
    # 7. REINICIAR ESTADISTICAS
    # -----------------------------------------

    def reiniciar_estadisticas(self):

        self.vaciar_cache(limpiar=True)
        self.lecturas = 0
        self.escrituras = 0
        self.bytes_leidos = 0
        self.bytes_escritos = 0

    # -----------------------------------------
    # 8. MOSTRAR ESTADISTICAS
    # -----------------------------------------

    def mostrar_estadisticas(self):

        estadisticas = self.obtener_estadisticas()

        print("\nESTADISTICAS DEL DISCO SIMULADO")
        print("--------------------------------")

        for nombre, valor in estadisticas.items():

            print(f"{nombre}: {valor}")


# -----------------------------------------
# 9. PRUEBA MANUAL
# -----------------------------------------

if __name__ == "__main__":

    disco = DiscoSimulado(
        "C5_arbol_b_mas/disco_prueba.bin"
    )

    print("DISCO SIMULADO - BUSCADOR JUDICIAL")

    indice = disco.reservar_bloque({
        "id": 1,
        "fecha": "2024-05-20",
        "tipo": "derecho administrativo"
    })

    print("\nBloque reservado:", indice)

    contenido = disco.leer_bloque(indice)

    print("\nContenido leído:")
    print(contenido)

    disco.mostrar_estadisticas()
