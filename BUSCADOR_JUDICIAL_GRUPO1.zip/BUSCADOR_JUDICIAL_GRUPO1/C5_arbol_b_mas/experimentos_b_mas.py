"""Benchmark reproducible del arbol B+ con presupuesto de memoria M.

Ejecutar desde la raiz del proyecto:
    python -m C5_arbol_b_mas.experimentos_b_mas

Modelo del experimento: cada nodo ocupa un bloque B=4096 bytes; el
buffer LRU dispone de M=4 bloques (M/B=4 marcos). Con orden 8, cada
hoja puede alojar hasta 7 claves, por lo que el presupuesto equivale a
28 registros de hoja; los tamaños N comienzan en 1000 (M_reg <= N/20).
Los contadores reportan transferencias fisicas al archivo simulado.
"""

import csv
import math
import statistics
import tempfile
import time
from datetime import date, timedelta
from pathlib import Path

from C5_arbol_b_mas.arbol_b_mas import ArbolBMas

RAIZ = Path(__file__).resolve().parent.parent
RUTA_CSV = Path(__file__).resolve().parent / "resultados_b_mas.csv"
TAMANOS = (1000, 2000, 4000, 8000, 16000)
REPETICIONES = 5
ORDEN = 8
B_BYTES = 4096
M_BLOQUES = 4
M_BYTES = M_BLOQUES * B_BYTES


def generar_registros(cantidad):
    inicio = date(2010, 1, 1)
    return [((inicio + timedelta(days=i)).isoformat(), i + 1)
            for i in range(cantidad)]


def altura_teorica(cantidad, orden=ORDEN):
    return max(1, math.ceil(math.log(max(1, cantidad), orden)) + 1)


def medir_fases(cantidad):
    registros = generar_registros(cantidad)  # fuera del tiempo medido
    tiempos_insertar, tiempos_punto, tiempos_rango = [], [], []
    estadisticas_fases = None

    for _ in range(REPETICIONES):
        with tempfile.TemporaryDirectory(prefix="experimento_bmas_") as td:
            arbol = ArbolBMas(
                orden=ORDEN, ruta_disco=str(Path(td) / "arbol.bin"),
                tamano_bloque=B_BYTES, memoria_bytes=M_BYTES
            )

            inicio = time.perf_counter()
            for fecha, identificador in registros:
                arbol.insertar(fecha, identificador)
            tiempos_insertar.append(time.perf_counter() - inicio)
            stats_insert = arbol.obtener_estadisticas()  # vacia bloques sucios

            arbol.disco.reiniciar_estadisticas()  # vacia buffer y reinicia E/S
            fecha_objetivo, id_objetivo = registros[cantidad // 2]
            inicio = time.perf_counter()
            encontrados = arbol.buscar(fecha_objetivo)
            tiempos_punto.append(time.perf_counter() - inicio)
            assert encontrados == [id_objetivo]
            stats_point = arbol.obtener_estadisticas()

            arbol.disco.reiniciar_estadisticas()
            fecha_inicio = registros[cantidad // 4][0]
            fecha_fin = registros[(3 * cantidad) // 4][0]
            inicio = time.perf_counter()
            encontrados_rango = arbol.buscar_rango(fecha_inicio, fecha_fin)
            tiempos_rango.append(time.perf_counter() - inicio)
            stats_range = arbol.obtener_estadisticas()

            estadisticas_fases = (stats_insert, stats_point, stats_range, len(encontrados_rango))

    si, sp, sr, cantidad_rango = estadisticas_fases
    h = altura_teorica(cantidad)
    ocupacion_minima_hoja = max(1, ORDEN // 2)
    hojas_rango = math.ceil(cantidad_rango / ocupacion_minima_hoja)
    # Cotas superiores de E/S derivadas de visitar como maximo h niveles
    # y escribir como maximo dos bloques por nivel mas la nueva raiz.
    pred_insert_reads = cantidad * h
    pred_insert_writes = cantidad * (2 * h + 1)
    pred_point_reads = h
    pred_range_reads = h + hojas_rango

    return {
        "N_registros": cantidad, "repeticiones": REPETICIONES,
        "orden_f": ORDEN, "B_bytes": B_BYTES, "M_bytes": M_BYTES,
        "M_sobre_B_bloques": M_BLOQUES, "M_registros_equivalentes": M_BLOQUES * (ORDEN - 1),
        "altura_predicha_h": h, "ocupacion_minima_hoja_B_leaf": ocupacion_minima_hoja,
        "resultados_rango_R": cantidad_rango,
        "mediana_insercion_s": statistics.median(tiempos_insertar),
        "mediana_busqueda_puntual_s": statistics.median(tiempos_punto),
        "mediana_busqueda_rango_s": statistics.median(tiempos_rango),
        "insert_lecturas_predichas_cota": pred_insert_reads,
        "insert_lecturas_contadas": si["lecturas"],
        "insert_escrituras_predichas_cota": pred_insert_writes,
        "insert_escrituras_contadas": si["escrituras"],
        "punto_lecturas_predichas": pred_point_reads,
        "punto_lecturas_contadas": sp["lecturas"],
        "rango_lecturas_predichas_cota": pred_range_reads,
        "rango_lecturas_contadas": sr["lecturas"],
        "rango_escrituras_contadas": sr["escrituras"],
        "bloques_archivo": si["bloques_ocupados"],
    }


def ejecutar_experimentos():
    resultados = [medir_fases(n) for n in TAMANOS]
    RUTA_CSV.parent.mkdir(parents=True, exist_ok=True)
    with RUTA_CSV.open("w", newline="", encoding="utf-8") as archivo:
        escritor = csv.DictWriter(archivo, fieldnames=list(resultados[0]))
        escritor.writeheader()
        escritor.writerows(resultados)
    print("EXPERIMENTOS C5 FINALIZADOS (M/B EXPLICITO)")
    for fila in resultados:
        print(fila)
    print(f"Resultados guardados en: {RUTA_CSV}")
    return resultados


if __name__ == "__main__":
    ejecutar_experimentos()
